/*
 * rtmodel.h
 *
 * Code generation for Simulink model "Torque_Control_ESP32_V6".
 *
 * Simulink Coder version                : 24.1 (R2024a) 19-Nov-2023
 * C source code generated on : Tue Sep 10 17:00:30 2024
 *
 * Note that the generated code is not dependent on this header file.
 * The file is used in cojuction with the automatic build procedure.
 * It is included by the sample main executable harness
 * MATLAB/rtw/c/src/common/rt_main.c.
 *
 */

#ifndef rtmodel_h_
#define rtmodel_h_
#include "Torque_Control_ESP32_V6.h"

/* Macros generated for backwards compatibility  */
#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((void*) 0)
#endif
#endif                                 /* rtmodel_h_ */
