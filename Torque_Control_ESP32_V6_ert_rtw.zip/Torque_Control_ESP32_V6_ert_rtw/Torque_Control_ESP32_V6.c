/*
 * Torque_Control_ESP32_V6.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Torque_Control_ESP32_V6".
 *
 * Model version              : 3.6
 * Simulink Coder version : 24.1 (R2024a) 19-Nov-2023
 * C source code generated on : Tue Sep 10 17:00:30 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Torque_Control_ESP32_V6.h"
#include <math.h>
#include "rtwtypes.h"
#include "zero_crossing_types.h"
#include <stddef.h>
#include "solver_zc.h"
#ifndef slZcHadEvent
#define slZcHadEvent(ev, zcsDir)       (((ev) & (zcsDir)) != 0x00 )
#endif

#ifndef slZcUnAliasEvents
#define slZcUnAliasEvents(evL, evR)    ((((slZcHadEvent((evL), (SL_ZCS_EVENT_N2Z)) && slZcHadEvent((evR), (SL_ZCS_EVENT_Z2P))) || (slZcHadEvent((evL), (SL_ZCS_EVENT_P2Z)) && slZcHadEvent((evR), (SL_ZCS_EVENT_Z2N)))) ? (SL_ZCS_EVENT_NUL) : (evR)))
#endif

#define NumBitsPerChar                 8U

/* Block parameters (default storage) */
P_Torque_Control_ESP32_V6_T Torque_Control_ESP32_V6_P = {
  /* Mask Parameter: CompareToConstant_const
   * Referenced by: '<S8>/Constant'
   */
  1.0F,

  /* Mask Parameter: CompareToConstant_const_b
   * Referenced by: '<S20>/Constant'
   */
  100.0F,

  /* Mask Parameter: CompareToConstant1_const
   * Referenced by: '<S21>/Constant'
   */
  0.0F,

  /* Mask Parameter: CompareToConstant2_const
   * Referenced by: '<S22>/Constant'
   */
  100.0F,

  /* Mask Parameter: CompareToConstant3_const
   * Referenced by: '<S23>/Constant'
   */
  0.0F,

  /* Mask Parameter: CompareToConstant5_const
   * Referenced by: '<S25>/Constant'
   */
  25.0F,

  /* Mask Parameter: CompareToConstant4_const
   * Referenced by: '<S24>/Constant'
   */
  20.0F,

  /* Mask Parameter: CompareToConstant_const_a
   * Referenced by: '<S9>/Constant'
   */
  4000.0F,

  /* Mask Parameter: CompareToConstant6_const
   * Referenced by: '<S26>/Constant'
   */
  false,

  /* Mask Parameter: WrapToZero_Threshold
   * Referenced by: '<S32>/FixPt Switch'
   */
  100U,

  /* Mask Parameter: WrapToZero_Threshold_b
   * Referenced by: '<S34>/FixPt Switch'
   */
  100U,

  /* Mask Parameter: CompareToConstant7_const
   * Referenced by: '<S27>/Constant'
   */
  100U,

  /* Mask Parameter: CompareToConstant8_const
   * Referenced by: '<S28>/Constant'
   */
  100U,

  /* Expression: -1
   * Referenced by: '<S2>/Analog Input1'
   */
  -1.0,

  /* Expression: -1
   * Referenced by: '<S2>/Analog Input4'
   */
  -1.0,

  /* Expression: -1
   * Referenced by: '<S2>/Analog Input5'
   */
  -1.0,

  /* Expression: -1
   * Referenced by: '<S2>/Analog Input6'
   */
  -1.0,

  /* Expression: -1
   * Referenced by: '<S2>/Analog Input7'
   */
  -1.0,

  /* Expression: -1
   * Referenced by: '<S2>/Digital Input'
   */
  -1.0,

  /* Expression: -1
   * Referenced by: '<S2>/Digital Input1'
   */
  -1.0,

  /* Expression: -1
   * Referenced by: '<S2>/Digital Input2'
   */
  -1.0,

  /* Expression: -1
   * Referenced by: '<S2>/Digital Input3'
   */
  -1.0,

  /* Expression: -1
   * Referenced by: '<S2>/Digital Input4'
   */
  -1.0,

  /* Expression: 0
   * Referenced by: '<S2>/Constant13'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S2>/Constant10'
   */
  1.0,

  /* Expression: 60
   * Referenced by: '<S2>/Constant14'
   */
  60.0,

  /* Expression: 0
   * Referenced by: '<S2>/Constant16'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S2>/Constant15'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<S2>/Constant19'
   */
  0.0,

  /* Expression: 5000
   * Referenced by: '<S2>/Constant9'
   */
  5000.0,

  /* Expression: 0
   * Referenced by: '<S2>/Constant11'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S2>/Switch9'
   */
  0.0,

  /* Expression: 24.11483253588517
   * Referenced by: '<S2>/VehSpd'
   */
  24.114832535885171,

  /* Expression: 2*pi*0.3*3.6
   * Referenced by: '<S2>/sec1'
   */
  6.785840131753953,

  /* Expression: 60
   * Referenced by: '<S2>/sec'
   */
  60.0,

  /* Expression: 8
   * Referenced by: '<S2>/TransmRatio'
   */
  8.0,

  /* Expression: 0
   * Referenced by: '<S2>/Constant1'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S2>/Constant2'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S2>/Switch'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S2>/Switch2'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S2>/Constant4'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S2>/Switch4'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S2>/Constant'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<S2>/Switch1'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S2>/Constant5'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S2>/Switch5'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S2>/Constant6'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S2>/Switch6'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S2>/Constant7'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S2>/Constant8'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S2>/Switch7'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S2>/Switch8'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S2>/Constant3'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S2>/Switch3'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S18>/Constant2'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S18>/Constant4'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S18>/Constant'
   */
  0.0,

  /* Expression: 50
   * Referenced by: '<S4>/Pulse Generator1'
   */
  50.0,

  /* Expression: 50
   * Referenced by: '<S4>/Pulse Generator1'
   */
  50.0,

  /* Expression: 10
   * Referenced by: '<S4>/Pulse Generator1'
   */
  10.0,

  /* Expression: 0
   * Referenced by: '<S4>/Pulse Generator1'
   */
  0.0,

  /* Expression: Table
   * Referenced by: '<S2>/Curve3'
   */
  { 0.0F, 100.0F },

  /* Expression: BreakpointsForDimension1
   * Referenced by: '<S2>/Curve3'
   */
  { 200.0F, 4095.0F },

  /* Expression: Table
   * Referenced by: '<S2>/AccPed2Curve'
   */
  { 0.0F, 100.0F },

  /* Expression: BreakpointsForDimension1
   * Referenced by: '<S2>/AccPed2Curve'
   */
  { 200.0F, 4095.0F },

  /* Expression: Table
   * Referenced by: '<S2>/Curve2'
   */
  { 0.0F, 200.0F },

  /* Expression: BreakpointsForDimension1
   * Referenced by: '<S2>/Curve2'
   */
  { 200.0F, 4095.0F },

  /* Expression: Table
   * Referenced by: '<S2>/Curve1'
   */
  { 0.0F, 6000.0F },

  /* Expression: BreakpointsForDimension1
   * Referenced by: '<S2>/Curve1'
   */
  { 200.0F, 4095.0F },

  /* Expression: Table
   * Referenced by: '<S2>/AccPed1Curve'
   */
  { 0.0F, 100.0F },

  /* Expression: BreakpointsForDimension1
   * Referenced by: '<S2>/AccPed1Curve'
   */
  { 200.0F, 4095.0F },

  /* Computed Parameter: Constant_Value_l
   * Referenced by: '<S7>/Constant'
   */
  1.0F,

  /* Computed Parameter: Constant1_Value_h
   * Referenced by: '<S7>/Constant1'
   */
  0.0F,

  /* Computed Parameter: DrvMode_st_Y0
   * Referenced by: '<S7>/DrvMode_st'
   */
  0.0F,

  /* Computed Parameter: AccPed01_Y0
   * Referenced by: '<S2>/AccPed01'
   */
  0.0F,

  /* Computed Parameter: AccPed02_Y0
   * Referenced by: '<S2>/AccPed02'
   */
  0.0F,

  /* Computed Parameter: BrkPedDig_st_Y0
   * Referenced by: '<S2>/BrkPedDig_st'
   */
  0.0F,

  /* Computed Parameter: BrkPedAnlg_Y0
   * Referenced by: '<S2>/BrkPedAnlg'
   */
  0.0F,

  /* Computed Parameter: RTD_st_Y0
   * Referenced by: '<S2>/RTD_st'
   */
  0.0F,

  /* Computed Parameter: AxelRpm_Y0
   * Referenced by: '<S2>/AxelRpm'
   */
  300.0F,

  /* Computed Parameter: VehSpeed_Y0
   * Referenced by: '<S2>/VehSpeed'
   */
  0.0F,

  /* Computed Parameter: TempSensr_Y0
   * Referenced by: '<S2>/TempSensr'
   */
  0.0F,

  /* Computed Parameter: Gear_st_Y0
   * Referenced by: '<S2>/Gear_st'
   */
  300.0F,

  /* Computed Parameter: Constant12_Value
   * Referenced by: '<S2>/Constant12'
   */
  100.0F,

  /* Computed Parameter: Delay_InitialCondition
   * Referenced by: '<S2>/Delay'
   */
  0.0F,

  /* Computed Parameter: Constant_Value_i
   * Referenced by: '<S1>/Constant'
   */
  1.0F,

  /* Computed Parameter: Constant1_Value_i
   * Referenced by: '<S1>/Constant1'
   */
  0.0F,

  /* Computed Parameter: Switch_Threshold_m
   * Referenced by: '<S1>/Switch'
   */
  80.0F,

  /* Computed Parameter: brkdefault_Value
   * Referenced by: '<S6>/brkdefault'
   */
  0.0F,

  /* Computed Parameter: AccPedReq_Y0
   * Referenced by: '<S6>/AccPedReq'
   */
  0.0F,

  /* Computed Parameter: AnlgBrkPrsnt_Value
   * Referenced by: '<S6>/AnlgBrkPrsnt'
   */
  1.0F,

  /* Computed Parameter: Switch1_Threshold_f
   * Referenced by: '<S19>/Switch1'
   */
  0.0F,

  /* Expression: Table
   * Referenced by: '<S12>/NormalMode'
   */
  { 0.0F, 5.0F, 10.0F, 15.0F, 20.0F, 25.0F, 30.0F, 35.0F, 40.0F, 45.0F, 50.0F,
    0.0F, 8.0F, 16.0F, 24.0F, 32.0F, 40.0F, 48.0F, 56.0F, 64.0F, 72.0F, 80.0F,
    0.0F, 11.0F, 22.0F, 33.0F, 44.0F, 55.0F, 66.0F, 77.0F, 88.0F, 99.0F, 110.0F,
    0.0F, 15.0F, 30.0F, 45.0F, 60.0F, 75.0F, 90.0F, 105.0F, 120.0F, 135.0F,
    150.0F, 0.0F, 18.0F, 36.0F, 54.0F, 72.0F, 90.0F, 108.0F, 126.0F, 144.0F,
    162.0F, 180.0F, 0.0F, 20.0F, 40.0F, 60.0F, 80.0F, 100.0F, 120.0F, 140.0F,
    160.0F, 180.0F, 200.0F, 0.0F, 20.0F, 40.0F, 60.0F, 80.0F, 100.0F, 120.0F,
    140.0F, 160.0F, 180.0F, 200.0F, 0.0F, 18.0F, 36.0F, 54.0F, 72.0F, 90.0F,
    108.0F, 126.0F, 144.0F, 162.0F, 180.0F, 0.0F, 16.0F, 32.0F, 48.0F, 64.0F,
    80.0F, 96.0F, 112.0F, 128.0F, 144.0F, 160.0F, 0.0F, 16.0F, 32.0F, 48.0F,
    64.0F, 80.0F, 96.0F, 112.0F, 128.0F, 144.0F, 160.0F },

  /* Expression: BreakpointsForDimension1
   * Referenced by: '<S12>/NormalMode'
   */
  { 0.0F, 10.0F, 20.0F, 30.0F, 40.0F, 50.0F, 60.0F, 70.0F, 80.0F, 90.0F, 100.0F
  },

  /* Expression: BreakpointsForDimension2
   * Referenced by: '<S12>/NormalMode'
   */
  { 0.0F, 10.0F, 20.0F, 30.0F, 40.0F, 60.0F, 80.0F, 100.0F, 125.0F, 150.0F },

  /* Expression: Table
   * Referenced by: '<S14>/SportMode'
   */
  { 0.0F, 5.0F, 10.0F, 15.0F, 20.0F, 25.0F, 30.0F, 35.0F, 40.0F, 45.0F, 50.0F,
    0.0F, 15.0F, 30.0F, 45.0F, 60.0F, 75.0F, 90.0F, 105.0F, 120.0F, 135.0F,
    150.0F, 0.0F, 17.0F, 34.0F, 51.0F, 68.0F, 85.0F, 102.0F, 119.0F, 136.0F,
    153.0F, 170.0F, 0.0F, 20.0F, 40.0F, 60.0F, 80.0F, 100.0F, 120.0F, 140.0F,
    160.0F, 180.0F, 200.0F, 0.0F, 20.0F, 40.0F, 60.0F, 80.0F, 100.0F, 120.0F,
    140.0F, 160.0F, 180.0F, 200.0F, 0.0F, 20.0F, 40.0F, 60.0F, 80.0F, 100.0F,
    120.0F, 140.0F, 160.0F, 180.0F, 200.0F, 0.0F, 20.0F, 40.0F, 60.0F, 80.0F,
    100.0F, 120.0F, 140.0F, 160.0F, 180.0F, 200.0F, 0.0F, 18.0F, 36.0F, 54.0F,
    72.0F, 90.0F, 108.0F, 126.0F, 144.0F, 162.0F, 180.0F, 0.0F, 16.0F, 32.0F,
    48.0F, 64.0F, 80.0F, 96.0F, 112.0F, 128.0F, 144.0F, 160.0F, 0.0F, 16.0F,
    32.0F, 48.0F, 64.0F, 80.0F, 96.0F, 112.0F, 128.0F, 144.0F, 160.0F },

  /* Expression: BreakpointsForDimension1
   * Referenced by: '<S14>/SportMode'
   */
  { 0.0F, 10.0F, 20.0F, 30.0F, 40.0F, 50.0F, 60.0F, 70.0F, 80.0F, 90.0F, 100.0F
  },

  /* Expression: BreakpointsForDimension2
   * Referenced by: '<S14>/SportMode'
   */
  { 0.0F, 10.0F, 20.0F, 30.0F, 40.0F, 60.0F, 80.0F, 100.0F, 125.0F, 150.0F },

  /* Expression: Table
   * Referenced by: '<S11>/EcoMode'
   */
  { 0.0F, 3.0F, 6.0F, 9.0F, 12.0F, 15.0F, 18.0F, 21.0F, 24.0F, 27.0F, 30.0F,
    0.0F, 5.0F, 10.0F, 15.0F, 20.0F, 25.0F, 30.0F, 35.0F, 40.0F, 45.0F, 50.0F,
    0.0F, 8.0F, 16.0F, 24.0F, 32.0F, 40.0F, 48.0F, 56.0F, 64.0F, 72.0F, 80.0F,
    0.0F, 12.0F, 24.0F, 36.0F, 48.0F, 60.0F, 72.0F, 84.0F, 96.0F, 108.0F, 120.0F,
    0.0F, 13.0F, 26.0F, 39.0F, 52.0F, 65.0F, 78.0F, 91.0F, 104.0F, 117.0F,
    130.0F, 0.0F, 15.0F, 30.0F, 45.0F, 60.0F, 75.0F, 90.0F, 105.0F, 120.0F,
    135.0F, 150.0F, 0.0F, 15.0F, 30.0F, 45.0F, 60.0F, 75.0F, 90.0F, 105.0F,
    120.0F, 135.0F, 150.0F, 0.0F, 13.0F, 26.0F, 39.0F, 52.0F, 65.0F, 78.0F,
    91.0F, 104.0F, 117.0F, 130.0F, 0.0F, 13.0F, 26.0F, 39.0F, 52.0F, 65.0F,
    78.0F, 91.0F, 104.0F, 117.0F, 130.0F, 0.0F, 12.0F, 24.0F, 36.0F, 48.0F,
    60.0F, 72.0F, 84.0F, 96.0F, 108.0F, 120.0F },

  /* Expression: BreakpointsForDimension1
   * Referenced by: '<S11>/EcoMode'
   */
  { 0.0F, 10.0F, 20.0F, 30.0F, 40.0F, 50.0F, 60.0F, 70.0F, 80.0F, 90.0F, 100.0F
  },

  /* Expression: BreakpointsForDimension2
   * Referenced by: '<S11>/EcoMode'
   */
  { 0.0F, 10.0F, 20.0F, 30.0F, 40.0F, 60.0F, 80.0F, 100.0F, 125.0F, 150.0F },

  /* Computed Parameter: Constant_Value_d
   * Referenced by: '<S10>/Constant'
   */
  0.0F,

  /* Computed Parameter: sec1_Value_o
   * Referenced by: '<S5>/sec1'
   */
  6.78584F,

  /* Computed Parameter: sec_Value_e
   * Referenced by: '<S5>/sec'
   */
  60.0F,

  /* Computed Parameter: TransmRat_Value
   * Referenced by: '<S5>/TransmRat'
   */
  8.0F,

  /* Computed Parameter: TrqReq_Y0
   * Referenced by: '<S5>/TrqReq'
   */
  0.0F,

  /* Computed Parameter: VehSpeedPrsnt_Value
   * Referenced by: '<S5>/VehSpeedPrsnt'
   */
  0.0F,

  /* Computed Parameter: Switch1_Threshold_e
   * Referenced by: '<S5>/Switch1'
   */
  0.0F,

  /* Computed Parameter: Merge_InitialOutput
   * Referenced by: '<S5>/Merge'
   */
  0.0F,

  /* Computed Parameter: Constant_Value_ij
   * Referenced by: '<S4>/Constant'
   */
  0.0F,

  /* Computed Parameter: NormalMode_maxIndex
   * Referenced by: '<S12>/NormalMode'
   */
  { 10U, 9U },

  /* Computed Parameter: SportMode_maxIndex
   * Referenced by: '<S14>/SportMode'
   */
  { 10U, 9U },

  /* Computed Parameter: EcoMode_maxIndex
   * Referenced by: '<S11>/EcoMode'
   */
  { 10U, 9U },

  /* Computed Parameter: Delay1_InitialCondition
   * Referenced by: '<S2>/Delay1'
   */
  false,

  /* Computed Parameter: FanReq_Y0
   * Referenced by: '<S1>/FanReq'
   */
  false,

  /* Computed Parameter: Fault_st_Y0
   * Referenced by: '<S6>/Fault_st'
   */
  false,

  /* Computed Parameter: LED01_Y0
   * Referenced by: '<S4>/LED01'
   */
  false,

  /* Computed Parameter: Constant_Value_c
   * Referenced by: '<S32>/Constant'
   */
  0U,

  /* Computed Parameter: Constant_Value_o
   * Referenced by: '<S34>/Constant'
   */
  0U,

  /* Computed Parameter: Output_InitialCondition
   * Referenced by: '<S29>/Output'
   */
  0U,

  /* Computed Parameter: Output_InitialCondition_o
   * Referenced by: '<S30>/Output'
   */
  0U,

  /* Computed Parameter: FixPtConstant_Value
   * Referenced by: '<S31>/FixPt Constant'
   */
  1U,

  /* Computed Parameter: FixPtConstant_Value_g
   * Referenced by: '<S33>/FixPt Constant'
   */
  1U
};

/* Block signals (default storage) */
B_Torque_Control_ESP32_V6_T Torque_Control_ESP32_V6_B;

/* Block states (default storage) */
DW_Torque_Control_ESP32_V6_T Torque_Control_ESP32_V6_DW;

/* Previous zero-crossings (trigger) states */
PrevZCX_Torque_Control_ESP32__T Torque_Control_ESP32_V6_PrevZCX;

/* Real-time model */
static RT_MODEL_Torque_Control_ESP32_T Torque_Control_ESP32_V6_M_;
RT_MODEL_Torque_Control_ESP32_T *const Torque_Control_ESP32_V6_M =
  &Torque_Control_ESP32_V6_M_;
static real32_T look2_iflf_linlcapw(real32_T u0, real32_T u1, const real32_T
  bp0[], const real32_T bp1[], const real32_T table[], const uint32_T maxIndex[],
  uint32_T stride);
static real32_T look1_iflf_linlcapw(real32_T u0, const real32_T bp0[], const
  real32_T table[], uint32_T maxIndex);
static ZCEventType rt_ZCFcn(ZCDirection zcDir, ZCSigState *prevZc, real_T
  currValue);

#define NOT_USING_NONFINITE_LITERALS   1

extern real_T rtInf;
extern real_T rtMinusInf;
extern real_T rtNaN;
extern real32_T rtInfF;
extern real32_T rtMinusInfF;
extern real32_T rtNaNF;
static void rt_InitInfAndNaN(size_t realSize);
static boolean_T rtIsInf(real_T value);
static boolean_T rtIsInfF(real32_T value);
static boolean_T rtIsNaN(real_T value);
static boolean_T rtIsNaNF(real32_T value);
typedef struct {
  struct {
    uint32_T wordH;
    uint32_T wordL;
  } words;
} BigEndianIEEEDouble;

typedef struct {
  struct {
    uint32_T wordL;
    uint32_T wordH;
  } words;
} LittleEndianIEEEDouble;

typedef struct {
  union {
    real32_T wordLreal;
    uint32_T wordLuint;
  } wordL;
} IEEESingle;

real_T rtInf;
real_T rtMinusInf;
real_T rtNaN;
real32_T rtInfF;
real32_T rtMinusInfF;
real32_T rtNaNF;
static real_T rtGetInf(void);
static real32_T rtGetInfF(void);
static real_T rtGetMinusInf(void);
static real32_T rtGetMinusInfF(void);
static real_T rtGetNaN(void);
static real32_T rtGetNaNF(void);

/* Detect zero crossings events. */
static ZCEventType rt_ZCFcn(ZCDirection zcDir, ZCSigState *prevZc, real_T
  currValue)
{
  slZcEventType zcsDir;
  slZcEventType tempEv;
  ZCEventType zcEvent = NO_ZCEVENT;    /* assume */

  /* zcEvent matrix */
  static const slZcEventType eventMatrix[4][4] = {
    /*          ZER              POS              NEG              UNK */
    { SL_ZCS_EVENT_NUL, SL_ZCS_EVENT_Z2P, SL_ZCS_EVENT_Z2N, SL_ZCS_EVENT_NUL },/* ZER */

    { SL_ZCS_EVENT_P2Z, SL_ZCS_EVENT_NUL, SL_ZCS_EVENT_P2N, SL_ZCS_EVENT_NUL },/* POS */

    { SL_ZCS_EVENT_N2Z, SL_ZCS_EVENT_N2P, SL_ZCS_EVENT_NUL, SL_ZCS_EVENT_NUL },/* NEG */

    { SL_ZCS_EVENT_NUL, SL_ZCS_EVENT_NUL, SL_ZCS_EVENT_NUL, SL_ZCS_EVENT_NUL }/* UNK */
  };

  /* get prevZcEvent and prevZcSign from prevZc */
  const slZcEventType prevEv = (slZcEventType)(((uint8_T)(*prevZc)) >> 2);
  const slZcSignalSignType prevSign = (slZcSignalSignType)(((uint8_T)(*prevZc))
    & (uint8_T)0x03);

  /* get current zcSignal sign from current zcSignal value */
  const slZcSignalSignType currSign = (slZcSignalSignType)((currValue) > 0.0 ?
    SL_ZCS_SIGN_POS :
    ((currValue) < 0.0 ? SL_ZCS_SIGN_NEG : SL_ZCS_SIGN_ZERO));

  /* get current zcEvent based on prev and current zcSignal value */
  slZcEventType currEv = eventMatrix[prevSign][currSign];

  /* get slZcEventType from ZCDirection */
  switch (zcDir) {
   case ANY_ZERO_CROSSING:
    zcsDir = SL_ZCS_EVENT_ALL;
    break;

   case FALLING_ZERO_CROSSING:
    zcsDir = SL_ZCS_EVENT_ALL_DN;
    break;

   case RISING_ZERO_CROSSING:
    zcsDir = SL_ZCS_EVENT_ALL_UP;
    break;

   default:
    zcsDir = SL_ZCS_EVENT_NUL;
    break;
  }

  /* had event, check if zc happened */
  if (slZcHadEvent(currEv, zcsDir)) {
    currEv = (slZcEventType)(slZcUnAliasEvents(prevEv, currEv));
  } else {
    currEv = SL_ZCS_EVENT_NUL;
  }

  /* Update prevZc */
  tempEv = (slZcEventType)(currEv << 2);/* shift left by 2 bits */
  *prevZc = (ZCSigState)((currSign) | (tempEv));
  if ((currEv & SL_ZCS_EVENT_ALL_DN) != 0) {
    zcEvent = FALLING_ZCEVENT;
  } else if ((currEv & SL_ZCS_EVENT_ALL_UP) != 0) {
    zcEvent = RISING_ZCEVENT;
  } else {
    zcEvent = NO_ZCEVENT;
  }

  return zcEvent;
}                                      /* rt_ZCFcn */

/*
 * Initialize the rtInf, rtMinusInf, and rtNaN needed by the
 * generated code. NaN is initialized as non-signaling. Assumes IEEE.
 */
static void rt_InitInfAndNaN(size_t realSize)
{
  (void) (realSize);
  rtNaN = rtGetNaN();
  rtNaNF = rtGetNaNF();
  rtInf = rtGetInf();
  rtInfF = rtGetInfF();
  rtMinusInf = rtGetMinusInf();
  rtMinusInfF = rtGetMinusInfF();
}

/* Test if value is infinite */
static boolean_T rtIsInf(real_T value)
{
  return (boolean_T)((value==rtInf || value==rtMinusInf) ? 1U : 0U);
}

/* Test if single-precision value is infinite */
static boolean_T rtIsInfF(real32_T value)
{
  return (boolean_T)(((value)==rtInfF || (value)==rtMinusInfF) ? 1U : 0U);
}

/* Test if value is not a number */
static boolean_T rtIsNaN(real_T value)
{
  boolean_T result = (boolean_T) 0;
  size_t bitsPerReal = sizeof(real_T) * (NumBitsPerChar);
  if (bitsPerReal == 32U) {
    result = rtIsNaNF((real32_T)value);
  } else {
    union {
      LittleEndianIEEEDouble bitVal;
      real_T fltVal;
    } tmpVal;

    tmpVal.fltVal = value;
    result = (boolean_T)((tmpVal.bitVal.words.wordH & 0x7FF00000) == 0x7FF00000 &&
                         ( (tmpVal.bitVal.words.wordH & 0x000FFFFF) != 0 ||
                          (tmpVal.bitVal.words.wordL != 0) ));
  }

  return result;
}

/* Test if single-precision value is not a number */
static boolean_T rtIsNaNF(real32_T value)
{
  IEEESingle tmp;
  tmp.wordL.wordLreal = value;
  return (boolean_T)( (tmp.wordL.wordLuint & 0x7F800000) == 0x7F800000 &&
                     (tmp.wordL.wordLuint & 0x007FFFFF) != 0 );
}

/*
 * Initialize rtInf needed by the generated code.
 * Inf is initialized as non-signaling. Assumes IEEE.
 */
static real_T rtGetInf(void)
{
  size_t bitsPerReal = sizeof(real_T) * (NumBitsPerChar);
  real_T inf = 0.0;
  if (bitsPerReal == 32U) {
    inf = rtGetInfF();
  } else {
    union {
      LittleEndianIEEEDouble bitVal;
      real_T fltVal;
    } tmpVal;

    tmpVal.bitVal.words.wordH = 0x7FF00000U;
    tmpVal.bitVal.words.wordL = 0x00000000U;
    inf = tmpVal.fltVal;
  }

  return inf;
}

/*
 * Initialize rtInfF needed by the generated code.
 * Inf is initialized as non-signaling. Assumes IEEE.
 */
static real32_T rtGetInfF(void)
{
  IEEESingle infF;
  infF.wordL.wordLuint = 0x7F800000U;
  return infF.wordL.wordLreal;
}

/*
 * Initialize rtMinusInf needed by the generated code.
 * Inf is initialized as non-signaling. Assumes IEEE.
 */
static real_T rtGetMinusInf(void)
{
  size_t bitsPerReal = sizeof(real_T) * (NumBitsPerChar);
  real_T minf = 0.0;
  if (bitsPerReal == 32U) {
    minf = rtGetMinusInfF();
  } else {
    union {
      LittleEndianIEEEDouble bitVal;
      real_T fltVal;
    } tmpVal;

    tmpVal.bitVal.words.wordH = 0xFFF00000U;
    tmpVal.bitVal.words.wordL = 0x00000000U;
    minf = tmpVal.fltVal;
  }

  return minf;
}

/*
 * Initialize rtMinusInfF needed by the generated code.
 * Inf is initialized as non-signaling. Assumes IEEE.
 */
static real32_T rtGetMinusInfF(void)
{
  IEEESingle minfF;
  minfF.wordL.wordLuint = 0xFF800000U;
  return minfF.wordL.wordLreal;
}

/*
 * Initialize rtNaN needed by the generated code.
 * NaN is initialized as non-signaling. Assumes IEEE.
 */
static real_T rtGetNaN(void)
{
  size_t bitsPerReal = sizeof(real_T) * (NumBitsPerChar);
  real_T nan = 0.0;
  if (bitsPerReal == 32U) {
    nan = rtGetNaNF();
  } else {
    union {
      LittleEndianIEEEDouble bitVal;
      real_T fltVal;
    } tmpVal;

    tmpVal.bitVal.words.wordH = 0xFFF80000U;
    tmpVal.bitVal.words.wordL = 0x00000000U;
    nan = tmpVal.fltVal;
  }

  return nan;
}

/*
 * Initialize rtNaNF needed by the generated code.
 * NaN is initialized as non-signaling. Assumes IEEE.
 */
static real32_T rtGetNaNF(void)
{
  IEEESingle nanF = { { 0.0F } };

  nanF.wordL.wordLuint = 0xFFC00000U;
  return nanF.wordL.wordLreal;
}

static real32_T look2_iflf_linlcapw(real32_T u0, real32_T u1, const real32_T
  bp0[], const real32_T bp1[], const real32_T table[], const uint32_T maxIndex[],
  uint32_T stride)
{
  real32_T fractions[2];
  real32_T frac;
  real32_T y;
  real32_T yL_0d0;
  uint32_T bpIndices[2];
  uint32_T bpIdx;
  uint32_T offset_1d;

  /* Column-major Lookup 2-D
     Search method: 'linear'
     Use previous index: 'off'
     Interpolation method: 'Linear point-slope'
     Extrapolation method: 'Clip'
     Use last breakpoint for index at or above upper limit: 'on'
     Remove protection against out-of-range input in generated code: 'off'
   */
  /* Prelookup - Index and Fraction
     Index Search method: 'linear'
     Extrapolation method: 'Clip'
     Use previous index: 'off'
     Use last breakpoint for index at or above upper limit: 'on'
     Remove protection against out-of-range input in generated code: 'off'
   */
  if (u0 <= bp0[0U]) {
    bpIdx = 0U;
    frac = 0.0F;
  } else if (u0 < bp0[maxIndex[0U]]) {
    /* Linear Search */
    for (bpIdx = maxIndex[0U] >> 1U; u0 < bp0[bpIdx]; bpIdx--) {
    }

    while (u0 >= bp0[bpIdx + 1U]) {
      bpIdx++;
    }

    frac = (u0 - bp0[bpIdx]) / (bp0[bpIdx + 1U] - bp0[bpIdx]);
  } else {
    bpIdx = maxIndex[0U];
    frac = 0.0F;
  }

  fractions[0U] = frac;
  bpIndices[0U] = bpIdx;

  /* Prelookup - Index and Fraction
     Index Search method: 'linear'
     Extrapolation method: 'Clip'
     Use previous index: 'off'
     Use last breakpoint for index at or above upper limit: 'on'
     Remove protection against out-of-range input in generated code: 'off'
   */
  if (u1 <= bp1[0U]) {
    bpIdx = 0U;
    frac = 0.0F;
  } else if (u1 < bp1[maxIndex[1U]]) {
    /* Linear Search */
    for (bpIdx = maxIndex[1U] >> 1U; u1 < bp1[bpIdx]; bpIdx--) {
    }

    while (u1 >= bp1[bpIdx + 1U]) {
      bpIdx++;
    }

    frac = (u1 - bp1[bpIdx]) / (bp1[bpIdx + 1U] - bp1[bpIdx]);
  } else {
    bpIdx = maxIndex[1U];
    frac = 0.0F;
  }

  /* Column-major Interpolation 2-D
     Interpolation method: 'Linear point-slope'
     Use last breakpoint for index at or above upper limit: 'on'
     Overflow mode: 'portable wrapping'
   */
  offset_1d = bpIdx * stride + bpIndices[0U];
  if (bpIndices[0U] == maxIndex[0U]) {
    y = table[offset_1d];
  } else {
    yL_0d0 = table[offset_1d];
    y = (table[offset_1d + 1U] - yL_0d0) * fractions[0U] + yL_0d0;
  }

  if (bpIdx == maxIndex[1U]) {
  } else {
    bpIdx = offset_1d + stride;
    if (bpIndices[0U] == maxIndex[0U]) {
      yL_0d0 = table[bpIdx];
    } else {
      yL_0d0 = table[bpIdx];
      yL_0d0 += (table[bpIdx + 1U] - yL_0d0) * fractions[0U];
    }

    y += (yL_0d0 - y) * frac;
  }

  return y;
}

static real32_T look1_iflf_linlcapw(real32_T u0, const real32_T bp0[], const
  real32_T table[], uint32_T maxIndex)
{
  real32_T frac;
  real32_T y;
  real32_T yL_0d0;
  uint32_T bpIdx;

  /* Column-major Lookup 1-D
     Search method: 'linear'
     Use previous index: 'off'
     Interpolation method: 'Linear point-slope'
     Extrapolation method: 'Clip'
     Use last breakpoint for index at or above upper limit: 'on'
     Remove protection against out-of-range input in generated code: 'off'
   */
  /* Prelookup - Index and Fraction
     Index Search method: 'linear'
     Extrapolation method: 'Clip'
     Use previous index: 'off'
     Use last breakpoint for index at or above upper limit: 'on'
     Remove protection against out-of-range input in generated code: 'off'
   */
  if (u0 <= bp0[0U]) {
    bpIdx = 0U;
    frac = 0.0F;
  } else if (u0 < bp0[maxIndex]) {
    /* Linear Search */
    for (bpIdx = maxIndex >> 1U; u0 < bp0[bpIdx]; bpIdx--) {
    }

    while (u0 >= bp0[bpIdx + 1U]) {
      bpIdx++;
    }

    frac = (u0 - bp0[bpIdx]) / (bp0[bpIdx + 1U] - bp0[bpIdx]);
  } else {
    bpIdx = maxIndex;
    frac = 0.0F;
  }

  /* Column-major Interpolation 1-D
     Interpolation method: 'Linear point-slope'
     Use last breakpoint for index at or above upper limit: 'on'
     Overflow mode: 'portable wrapping'
   */
  if (bpIdx == maxIndex) {
    y = table[bpIdx];
  } else {
    yL_0d0 = table[bpIdx];
    y = (table[bpIdx + 1U] - yL_0d0) * frac + yL_0d0;
  }

  return y;
}

/* Model step function */
void Torque_Control_ESP32_V6_step(void)
{
  int32_T idxDelay;
  real32_T den;
  uint32_T iterStart;
  uint16_T b_varargout_1;
  boolean_T c_value;
  ZCEventType zcEvent;

  /* S-Function (fcgen): '<Root>/Function-Call Generator1' incorporates:
   *  SubSystem: '<Root>/DataAcquisition'
   */
  /* MATLABSystem: '<S2>/Analog Input4' */
  if (Torque_Control_ESP32_V6_DW.obj_ac.SampleTime !=
      Torque_Control_ESP32_V6_P.AnalogInput4_SampleTime) {
    Torque_Control_ESP32_V6_DW.obj_ac.SampleTime =
      Torque_Control_ESP32_V6_P.AnalogInput4_SampleTime;
  }

  Torque_Control_ESP32_V6_DW.obj_ac.AnalogInDriverObj.MW_ANALOGIN_HANDLE =
    MW_AnalogIn_GetHandle(36U);
  MW_AnalogInSingle_ReadResult
    (Torque_Control_ESP32_V6_DW.obj_ac.AnalogInDriverObj.MW_ANALOGIN_HANDLE,
     &b_varargout_1, MW_ANALOGIN_UINT16);

  /* MATLABSystem: '<S2>/Analog Input4' */
  Torque_Control_ESP32_V6_B.AnalogInput4 = b_varargout_1;

  /* MATLABSystem: '<S2>/Analog Input5' */
  if (Torque_Control_ESP32_V6_DW.obj_a.SampleTime !=
      Torque_Control_ESP32_V6_P.AnalogInput5_SampleTime) {
    Torque_Control_ESP32_V6_DW.obj_a.SampleTime =
      Torque_Control_ESP32_V6_P.AnalogInput5_SampleTime;
  }

  Torque_Control_ESP32_V6_DW.obj_a.AnalogInDriverObj.MW_ANALOGIN_HANDLE =
    MW_AnalogIn_GetHandle(39U);
  MW_AnalogInSingle_ReadResult
    (Torque_Control_ESP32_V6_DW.obj_a.AnalogInDriverObj.MW_ANALOGIN_HANDLE,
     &b_varargout_1, MW_ANALOGIN_UINT16);

  /* MATLABSystem: '<S2>/Analog Input5' */
  Torque_Control_ESP32_V6_B.AnalogInput5 = b_varargout_1;

  /* Switch: '<S2>/Switch' incorporates:
   *  Constant: '<S2>/Constant1'
   */
  if (Torque_Control_ESP32_V6_P.Constant1_Value >
      Torque_Control_ESP32_V6_P.Switch_Threshold) {
    /* Switch: '<S2>/Switch' incorporates:
     *  Constant: '<S2>/Constant12'
     */
    Torque_Control_ESP32_V6_B.AccPed01 =
      Torque_Control_ESP32_V6_P.Constant12_Value;
  } else {
    /* DataTypeConversion: '<S2>/Data Type Conversion4' */
    Torque_Control_ESP32_V6_B.DataTypeConversion4 =
      Torque_Control_ESP32_V6_B.AnalogInput4;

    /* Lookup_n-D: '<S2>/AccPed1Curve' incorporates:
     *  DataTypeConversion: '<S2>/Data Type Conversion4'
     */
    Torque_Control_ESP32_V6_B.AccPed1Curve = look1_iflf_linlcapw
      (Torque_Control_ESP32_V6_B.DataTypeConversion4,
       Torque_Control_ESP32_V6_P.AccPed1Curve_bp01Data,
       Torque_Control_ESP32_V6_P.AccPed1Curve_tableData, 1U);

    /* Switch: '<S2>/Switch' */
    Torque_Control_ESP32_V6_B.AccPed01 = Torque_Control_ESP32_V6_B.AccPed1Curve;
  }

  /* End of Switch: '<S2>/Switch' */

  /* Switch: '<S2>/Switch2' incorporates:
   *  Constant: '<S2>/Constant2'
   */
  if (Torque_Control_ESP32_V6_P.Constant2_Value >
      Torque_Control_ESP32_V6_P.Switch2_Threshold) {
    /* Product: '<S2>/Product' incorporates:
     *  Constant: '<S2>/Constant10'
     *  Constant: '<S2>/Constant12'
     */
    Torque_Control_ESP32_V6_B.Product =
      Torque_Control_ESP32_V6_P.Constant12_Value *
      Torque_Control_ESP32_V6_P.Constant10_Value;

    /* Switch: '<S2>/Switch2' */
    Torque_Control_ESP32_V6_B.AccPed02 = (real32_T)
      Torque_Control_ESP32_V6_B.Product;
  } else {
    /* DataTypeConversion: '<S2>/Data Type Conversion3' */
    Torque_Control_ESP32_V6_B.DataTypeConversion3 =
      Torque_Control_ESP32_V6_B.AnalogInput5;

    /* Lookup_n-D: '<S2>/AccPed2Curve' incorporates:
     *  DataTypeConversion: '<S2>/Data Type Conversion3'
     */
    Torque_Control_ESP32_V6_B.AccPed2Curve = look1_iflf_linlcapw
      (Torque_Control_ESP32_V6_B.DataTypeConversion3,
       Torque_Control_ESP32_V6_P.AccPed2Curve_bp01Data,
       Torque_Control_ESP32_V6_P.AccPed2Curve_tableData, 1U);

    /* Switch: '<S2>/Switch2' */
    Torque_Control_ESP32_V6_B.AccPed02 = Torque_Control_ESP32_V6_B.AccPed2Curve;
  }

  /* End of Switch: '<S2>/Switch2' */

  /* MATLABSystem: '<S2>/Digital Input' */
  if (Torque_Control_ESP32_V6_DW.obj_ny.SampleTime !=
      Torque_Control_ESP32_V6_P.DigitalInput_SampleTime) {
    Torque_Control_ESP32_V6_DW.obj_ny.SampleTime =
      Torque_Control_ESP32_V6_P.DigitalInput_SampleTime;
  }

  c_value = readDigitalPin(25);

  /* MATLABSystem: '<S2>/Digital Input' */
  Torque_Control_ESP32_V6_B.DigitalInput = c_value;

  /* Switch: '<S2>/Switch4' incorporates:
   *  Constant: '<S2>/Constant4'
   */
  if (Torque_Control_ESP32_V6_P.Constant4_Value >
      Torque_Control_ESP32_V6_P.Switch4_Threshold) {
    /* Switch: '<S2>/Switch4' incorporates:
     *  Constant: '<S2>/Constant16'
     */
    Torque_Control_ESP32_V6_B.Switch4 = (real32_T)
      Torque_Control_ESP32_V6_P.Constant16_Value;
  } else {
    /* Switch: '<S2>/Switch4' */
    Torque_Control_ESP32_V6_B.Switch4 = Torque_Control_ESP32_V6_B.DigitalInput;
  }

  /* End of Switch: '<S2>/Switch4' */

  /* MATLABSystem: '<S2>/Analog Input7' */
  if (Torque_Control_ESP32_V6_DW.obj.SampleTime !=
      Torque_Control_ESP32_V6_P.AnalogInput7_SampleTime) {
    Torque_Control_ESP32_V6_DW.obj.SampleTime =
      Torque_Control_ESP32_V6_P.AnalogInput7_SampleTime;
  }

  Torque_Control_ESP32_V6_DW.obj.AnalogInDriverObj.MW_ANALOGIN_HANDLE =
    MW_AnalogIn_GetHandle(35U);
  MW_AnalogInSingle_ReadResult
    (Torque_Control_ESP32_V6_DW.obj.AnalogInDriverObj.MW_ANALOGIN_HANDLE,
     &b_varargout_1, MW_ANALOGIN_UINT16);

  /* MATLABSystem: '<S2>/Analog Input7' */
  Torque_Control_ESP32_V6_B.AnalogInput7 = b_varargout_1;

  /* Switch: '<S2>/Switch1' incorporates:
   *  Constant: '<S2>/Constant'
   */
  if (Torque_Control_ESP32_V6_P.Constant_Value >
      Torque_Control_ESP32_V6_P.Switch1_Threshold) {
    /* Switch: '<S2>/Switch1' incorporates:
     *  Constant: '<S2>/Constant13'
     */
    Torque_Control_ESP32_V6_B.Switch1_b = (real32_T)
      Torque_Control_ESP32_V6_P.Constant13_Value;
  } else {
    /* DataTypeConversion: '<S2>/Data Type Conversion1' */
    Torque_Control_ESP32_V6_B.DataTypeConversion1 =
      Torque_Control_ESP32_V6_B.AnalogInput7;

    /* Lookup_n-D: '<S2>/Curve3' incorporates:
     *  DataTypeConversion: '<S2>/Data Type Conversion1'
     */
    Torque_Control_ESP32_V6_B.Curve3 = look1_iflf_linlcapw
      (Torque_Control_ESP32_V6_B.DataTypeConversion1,
       Torque_Control_ESP32_V6_P.Curve3_bp01Data,
       Torque_Control_ESP32_V6_P.Curve3_tableData, 1U);

    /* Switch: '<S2>/Switch1' */
    Torque_Control_ESP32_V6_B.Switch1_b = Torque_Control_ESP32_V6_B.Curve3;
  }

  /* End of Switch: '<S2>/Switch1' */

  /* MATLABSystem: '<S2>/Digital Input1' */
  if (Torque_Control_ESP32_V6_DW.obj_g.SampleTime !=
      Torque_Control_ESP32_V6_P.DigitalInput1_SampleTime) {
    Torque_Control_ESP32_V6_DW.obj_g.SampleTime =
      Torque_Control_ESP32_V6_P.DigitalInput1_SampleTime;
  }

  c_value = readDigitalPin(26);

  /* MATLABSystem: '<S2>/Digital Input1' */
  Torque_Control_ESP32_V6_B.DigitalInput1 = c_value;

  /* Switch: '<S2>/Switch5' incorporates:
   *  Constant: '<S2>/Constant5'
   */
  if (Torque_Control_ESP32_V6_P.Constant5_Value >
      Torque_Control_ESP32_V6_P.Switch5_Threshold) {
    /* Switch: '<S2>/Switch5' incorporates:
     *  Constant: '<S2>/Constant15'
     */
    Torque_Control_ESP32_V6_B.RTD_st = (real32_T)
      Torque_Control_ESP32_V6_P.Constant15_Value;
  } else {
    /* Switch: '<S2>/Switch5' */
    Torque_Control_ESP32_V6_B.RTD_st = Torque_Control_ESP32_V6_B.DigitalInput1;
  }

  /* End of Switch: '<S2>/Switch5' */

  /* MATLABSystem: '<S2>/Digital Input2' */
  if (Torque_Control_ESP32_V6_DW.obj_n.SampleTime !=
      Torque_Control_ESP32_V6_P.DigitalInput2_SampleTime) {
    Torque_Control_ESP32_V6_DW.obj_n.SampleTime =
      Torque_Control_ESP32_V6_P.DigitalInput2_SampleTime;
  }

  c_value = readDigitalPin(27);

  /* MATLABSystem: '<S2>/Digital Input2' */
  Torque_Control_ESP32_V6_B.DigitalInput2 = c_value;

  /* Delay: '<S2>/Delay1' */
  Torque_Control_ESP32_V6_B.Delay1 = Torque_Control_ESP32_V6_DW.Delay1_DSTATE[0];

  /* Delay: '<S2>/Delay' */
  Torque_Control_ESP32_V6_B.Delay = Torque_Control_ESP32_V6_DW.Delay_DSTATE[0];

  /* Switch: '<S2>/Switch6' incorporates:
   *  Constant: '<S2>/Constant6'
   */
  if (Torque_Control_ESP32_V6_P.Constant6_Value >
      Torque_Control_ESP32_V6_P.Switch6_Threshold) {
    /* Switch: '<S2>/Switch6' incorporates:
     *  Constant: '<S2>/Constant19'
     */
    Torque_Control_ESP32_V6_B.Switch6 =
      Torque_Control_ESP32_V6_P.Constant19_Value;
  } else {
    /* Logic: '<S2>/AND' */
    Torque_Control_ESP32_V6_B.AND_a = Torque_Control_ESP32_V6_B.DigitalInput2 &&
      Torque_Control_ESP32_V6_B.Delay1;

    /* Switch: '<S2>/Switch6' */
    Torque_Control_ESP32_V6_B.Switch6 = Torque_Control_ESP32_V6_B.AND_a;
  }

  /* End of Switch: '<S2>/Switch6' */

  /* Outputs for Triggered SubSystem: '<S2>/Triggered Subsystem' incorporates:
   *  TriggerPort: '<S7>/Trigger'
   */
  zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,
                     &Torque_Control_ESP32_V6_PrevZCX.TriggeredSubsystem_Trig_ZCE,
                     (Torque_Control_ESP32_V6_B.Switch6));
  if (zcEvent != NO_ZCEVENT) {
    /* RelationalOperator: '<S8>/Compare' incorporates:
     *  Constant: '<S8>/Constant'
     */
    Torque_Control_ESP32_V6_B.Compare_j = Torque_Control_ESP32_V6_B.Delay <=
      Torque_Control_ESP32_V6_P.CompareToConstant_const;

    /* Switch: '<S7>/Switch' */
    if (Torque_Control_ESP32_V6_B.Compare_j) {
      /* Sum: '<S7>/Sum' incorporates:
       *  Constant: '<S7>/Constant'
       */
      Torque_Control_ESP32_V6_B.Sum = Torque_Control_ESP32_V6_B.Delay +
        Torque_Control_ESP32_V6_P.Constant_Value_l;

      /* Switch: '<S7>/Switch' */
      Torque_Control_ESP32_V6_B.Switch_h = Torque_Control_ESP32_V6_B.Sum;
    } else {
      /* Switch: '<S7>/Switch' incorporates:
       *  Constant: '<S7>/Constant1'
       */
      Torque_Control_ESP32_V6_B.Switch_h =
        Torque_Control_ESP32_V6_P.Constant1_Value_h;
    }

    /* End of Switch: '<S7>/Switch' */
  }

  /* End of Outputs for SubSystem: '<S2>/Triggered Subsystem' */

  /* MATLABSystem: '<S2>/Analog Input1' */
  if (Torque_Control_ESP32_V6_DW.obj_h.SampleTime !=
      Torque_Control_ESP32_V6_P.AnalogInput1_SampleTime) {
    Torque_Control_ESP32_V6_DW.obj_h.SampleTime =
      Torque_Control_ESP32_V6_P.AnalogInput1_SampleTime;
  }

  Torque_Control_ESP32_V6_DW.obj_h.AnalogInDriverObj.MW_ANALOGIN_HANDLE =
    MW_AnalogIn_GetHandle(14U);
  MW_AnalogInSingle_ReadResult
    (Torque_Control_ESP32_V6_DW.obj_h.AnalogInDriverObj.MW_ANALOGIN_HANDLE,
     &b_varargout_1, MW_ANALOGIN_UINT16);

  /* MATLABSystem: '<S2>/Analog Input1' */
  Torque_Control_ESP32_V6_B.AnalogInput1 = b_varargout_1;

  /* MATLABSystem: '<S2>/Digital Input3' */
  if (Torque_Control_ESP32_V6_DW.obj_c.SampleTime !=
      Torque_Control_ESP32_V6_P.DigitalInput3_SampleTime) {
    Torque_Control_ESP32_V6_DW.obj_c.SampleTime =
      Torque_Control_ESP32_V6_P.DigitalInput3_SampleTime;
  }

  c_value = readDigitalPin(4);

  /* MATLABSystem: '<S2>/Digital Input3' */
  Torque_Control_ESP32_V6_B.DigitalInput3 = c_value;

  /* Switch: '<S2>/Switch7' incorporates:
   *  Constant: '<S2>/Constant11'
   *  Constant: '<S2>/Constant7'
   *  Switch: '<S2>/Switch9'
   */
  if (Torque_Control_ESP32_V6_P.Constant7_Value >
      Torque_Control_ESP32_V6_P.Switch7_Threshold) {
    /* Switch: '<S2>/Switch7' incorporates:
     *  Constant: '<S2>/Constant9'
     */
    Torque_Control_ESP32_V6_B.Switch7 = (real32_T)
      Torque_Control_ESP32_V6_P.Constant9_Value;
  } else {
    if (Torque_Control_ESP32_V6_P.Constant11_Value >
        Torque_Control_ESP32_V6_P.Switch9_Threshold) {
      /* Switch: '<S2>/Switch9' */
      Torque_Control_ESP32_V6_B.Switch9 =
        Torque_Control_ESP32_V6_B.DigitalInput3;
    } else {
      /* DataTypeConversion: '<S2>/Data Type Conversion5' incorporates:
       *  Switch: '<S2>/Switch9'
       */
      Torque_Control_ESP32_V6_B.DataTypeConversion5 =
        Torque_Control_ESP32_V6_B.AnalogInput1;

      /* Lookup_n-D: '<S2>/Curve1' incorporates:
       *  DataTypeConversion: '<S2>/Data Type Conversion5'
       *  Switch: '<S2>/Switch9'
       */
      Torque_Control_ESP32_V6_B.Curve1 = look1_iflf_linlcapw
        (Torque_Control_ESP32_V6_B.DataTypeConversion5,
         Torque_Control_ESP32_V6_P.Curve1_bp01Data,
         Torque_Control_ESP32_V6_P.Curve1_tableData, 1U);

      /* Switch: '<S2>/Switch9' */
      Torque_Control_ESP32_V6_B.Switch9 = Torque_Control_ESP32_V6_B.Curve1;
    }

    /* Switch: '<S2>/Switch7' */
    Torque_Control_ESP32_V6_B.Switch7 = Torque_Control_ESP32_V6_B.Switch9;
  }

  /* End of Switch: '<S2>/Switch7' */

  /* Switch: '<S2>/Switch8' incorporates:
   *  Constant: '<S2>/Constant8'
   */
  if (Torque_Control_ESP32_V6_P.Constant8_Value >
      Torque_Control_ESP32_V6_P.Switch8_Threshold) {
    /* Switch: '<S2>/Switch8' incorporates:
     *  Constant: '<S2>/VehSpd'
     */
    Torque_Control_ESP32_V6_B.Switch8 = (real32_T)
      Torque_Control_ESP32_V6_P.VehSpd_Value;
  } else {
    /* Product: '<S2>/Divide2' incorporates:
     *  Constant: '<S2>/TransmRatio'
     */
    Torque_Control_ESP32_V6_B.Divide2 = Torque_Control_ESP32_V6_B.Switch7 /
      Torque_Control_ESP32_V6_P.TransmRatio_Value;

    /* Product: '<S2>/Divide' incorporates:
     *  Constant: '<S2>/sec'
     */
    Torque_Control_ESP32_V6_B.Divide = Torque_Control_ESP32_V6_B.Divide2 /
      Torque_Control_ESP32_V6_P.sec_Value;

    /* Product: '<S2>/Divide1' incorporates:
     *  Constant: '<S2>/sec1'
     */
    Torque_Control_ESP32_V6_B.Divide1 = Torque_Control_ESP32_V6_B.Divide *
      Torque_Control_ESP32_V6_P.sec1_Value;

    /* Switch: '<S2>/Switch8' */
    Torque_Control_ESP32_V6_B.Switch8 = (real32_T)
      Torque_Control_ESP32_V6_B.Divide1;
  }

  /* End of Switch: '<S2>/Switch8' */

  /* MATLABSystem: '<S2>/Analog Input6' */
  if (Torque_Control_ESP32_V6_DW.obj_j.SampleTime !=
      Torque_Control_ESP32_V6_P.AnalogInput6_SampleTime) {
    Torque_Control_ESP32_V6_DW.obj_j.SampleTime =
      Torque_Control_ESP32_V6_P.AnalogInput6_SampleTime;
  }

  Torque_Control_ESP32_V6_DW.obj_j.AnalogInDriverObj.MW_ANALOGIN_HANDLE =
    MW_AnalogIn_GetHandle(34U);
  MW_AnalogInSingle_ReadResult
    (Torque_Control_ESP32_V6_DW.obj_j.AnalogInDriverObj.MW_ANALOGIN_HANDLE,
     &b_varargout_1, MW_ANALOGIN_UINT16);

  /* MATLABSystem: '<S2>/Analog Input6' */
  Torque_Control_ESP32_V6_B.AnalogInput6 = b_varargout_1;

  /* Switch: '<S2>/Switch3' incorporates:
   *  Constant: '<S2>/Constant3'
   */
  if (Torque_Control_ESP32_V6_P.Constant3_Value >
      Torque_Control_ESP32_V6_P.Switch3_Threshold) {
    /* Switch: '<S2>/Switch3' incorporates:
     *  Constant: '<S2>/Constant14'
     */
    Torque_Control_ESP32_V6_B.Switch3 = (real32_T)
      Torque_Control_ESP32_V6_P.Constant14_Value;
  } else {
    /* DataTypeConversion: '<S2>/Data Type Conversion2' */
    Torque_Control_ESP32_V6_B.DataTypeConversion2 =
      Torque_Control_ESP32_V6_B.AnalogInput6;

    /* Lookup_n-D: '<S2>/Curve2' incorporates:
     *  DataTypeConversion: '<S2>/Data Type Conversion2'
     */
    Torque_Control_ESP32_V6_B.Curve2 = look1_iflf_linlcapw
      (Torque_Control_ESP32_V6_B.DataTypeConversion2,
       Torque_Control_ESP32_V6_P.Curve2_bp01Data,
       Torque_Control_ESP32_V6_P.Curve2_tableData, 1U);

    /* Switch: '<S2>/Switch3' */
    Torque_Control_ESP32_V6_B.Switch3 = Torque_Control_ESP32_V6_B.Curve2;
  }

  /* End of Switch: '<S2>/Switch3' */

  /* MATLABSystem: '<S2>/Digital Input4' */
  if (Torque_Control_ESP32_V6_DW.obj_p.SampleTime !=
      Torque_Control_ESP32_V6_P.DigitalInput4_SampleTime) {
    Torque_Control_ESP32_V6_DW.obj_p.SampleTime =
      Torque_Control_ESP32_V6_P.DigitalInput4_SampleTime;
  }

  c_value = readDigitalPin(5);

  /* MATLABSystem: '<S2>/Digital Input4' */
  Torque_Control_ESP32_V6_B.DigitalInput4 = c_value;

  /* Update for Delay: '<S2>/Delay1' */
  for (idxDelay = 0; idxDelay < 14; idxDelay++) {
    Torque_Control_ESP32_V6_DW.Delay1_DSTATE[idxDelay] =
      Torque_Control_ESP32_V6_DW.Delay1_DSTATE[idxDelay + 1];
  }

  Torque_Control_ESP32_V6_DW.Delay1_DSTATE[14] =
    Torque_Control_ESP32_V6_B.DigitalInput2;

  /* End of Update for Delay: '<S2>/Delay1' */

  /* Update for Delay: '<S2>/Delay' */
  Torque_Control_ESP32_V6_DW.Delay_DSTATE[0] =
    Torque_Control_ESP32_V6_DW.Delay_DSTATE[1];
  Torque_Control_ESP32_V6_DW.Delay_DSTATE[1] =
    Torque_Control_ESP32_V6_B.Switch_h;

  /* End of Outputs for S-Function (fcgen): '<Root>/Function-Call Generator1' */

  /* S-Function (fcgen): '<Root>/Function-Call Generator3' incorporates:
   *  SubSystem: '<Root>/SafetyCheck'
   */
  /* UnitDelay: '<S29>/Output' */
  Torque_Control_ESP32_V6_B.Output = Torque_Control_ESP32_V6_DW.Output_DSTATE;

  /* RelationalOperator: '<S27>/Compare' incorporates:
   *  Constant: '<S27>/Constant'
   */
  Torque_Control_ESP32_V6_B.Compare_a = Torque_Control_ESP32_V6_B.Output ==
    Torque_Control_ESP32_V6_P.CompareToConstant7_const;

  /* S-Function (sdspstatfcns): '<S18>/Mean' */
  if (Torque_Control_ESP32_V6_B.Compare_a) {
    Torque_Control_ESP32_V6_DW.Mean_Iteration = 0U;
  }

  iterStart = Torque_Control_ESP32_V6_DW.Mean_Iteration;
  Torque_Control_ESP32_V6_DW.Mean_Iteration = iterStart;
  Torque_Control_ESP32_V6_DW.Mean_Iteration++;
  if (Torque_Control_ESP32_V6_DW.Mean_Iteration > 1U) {
    Torque_Control_ESP32_V6_DW.Mean_AccVal += Torque_Control_ESP32_V6_B.AccPed01;
    den = (real32_T)Torque_Control_ESP32_V6_DW.Mean_Iteration;

    /* S-Function (sdspstatfcns): '<S18>/Mean' */
    Torque_Control_ESP32_V6_B.Mean = Torque_Control_ESP32_V6_DW.Mean_AccVal /
      den;
  } else {
    if (Torque_Control_ESP32_V6_DW.Mean_Iteration == 0U) {
      Torque_Control_ESP32_V6_DW.Mean_Iteration = 1U;
    }

    Torque_Control_ESP32_V6_DW.Mean_AccVal = Torque_Control_ESP32_V6_B.AccPed01;

    /* S-Function (sdspstatfcns): '<S18>/Mean' */
    Torque_Control_ESP32_V6_B.Mean = Torque_Control_ESP32_V6_B.AccPed01;
  }

  /* End of S-Function (sdspstatfcns): '<S18>/Mean' */

  /* RelationalOperator: '<S20>/Compare' incorporates:
   *  Constant: '<S20>/Constant'
   */
  Torque_Control_ESP32_V6_B.Compare_h = Torque_Control_ESP32_V6_B.Mean <=
    Torque_Control_ESP32_V6_P.CompareToConstant_const_b;

  /* RelationalOperator: '<S21>/Compare' incorporates:
   *  Constant: '<S21>/Constant'
   */
  Torque_Control_ESP32_V6_B.Compare_g = Torque_Control_ESP32_V6_B.Mean >=
    Torque_Control_ESP32_V6_P.CompareToConstant1_const;

  /* Logic: '<S18>/AND' */
  Torque_Control_ESP32_V6_B.AND = Torque_Control_ESP32_V6_B.Compare_h &&
    Torque_Control_ESP32_V6_B.Compare_g;

  /* UnitDelay: '<S30>/Output' */
  Torque_Control_ESP32_V6_B.Output_p =
    Torque_Control_ESP32_V6_DW.Output_DSTATE_n;

  /* RelationalOperator: '<S28>/Compare' incorporates:
   *  Constant: '<S28>/Constant'
   */
  Torque_Control_ESP32_V6_B.Compare_ge = Torque_Control_ESP32_V6_B.Output_p ==
    Torque_Control_ESP32_V6_P.CompareToConstant8_const;

  /* S-Function (sdspstatfcns): '<S18>/Mean1' */
  if (Torque_Control_ESP32_V6_B.Compare_ge) {
    Torque_Control_ESP32_V6_DW.Mean1_Iteration = 0U;
  }

  iterStart = Torque_Control_ESP32_V6_DW.Mean1_Iteration;
  Torque_Control_ESP32_V6_DW.Mean1_Iteration = iterStart;
  Torque_Control_ESP32_V6_DW.Mean1_Iteration++;
  if (Torque_Control_ESP32_V6_DW.Mean1_Iteration > 1U) {
    Torque_Control_ESP32_V6_DW.Mean1_AccVal +=
      Torque_Control_ESP32_V6_B.AccPed02;
    den = (real32_T)Torque_Control_ESP32_V6_DW.Mean1_Iteration;

    /* S-Function (sdspstatfcns): '<S18>/Mean1' */
    Torque_Control_ESP32_V6_B.Mean1 = Torque_Control_ESP32_V6_DW.Mean1_AccVal /
      den;
  } else {
    if (Torque_Control_ESP32_V6_DW.Mean1_Iteration == 0U) {
      Torque_Control_ESP32_V6_DW.Mean1_Iteration = 1U;
    }

    Torque_Control_ESP32_V6_DW.Mean1_AccVal = Torque_Control_ESP32_V6_B.AccPed02;

    /* S-Function (sdspstatfcns): '<S18>/Mean1' */
    Torque_Control_ESP32_V6_B.Mean1 = Torque_Control_ESP32_V6_B.AccPed02;
  }

  /* End of S-Function (sdspstatfcns): '<S18>/Mean1' */

  /* RelationalOperator: '<S22>/Compare' incorporates:
   *  Constant: '<S22>/Constant'
   */
  Torque_Control_ESP32_V6_B.Compare_c = Torque_Control_ESP32_V6_B.Mean1 <=
    Torque_Control_ESP32_V6_P.CompareToConstant2_const;

  /* RelationalOperator: '<S23>/Compare' incorporates:
   *  Constant: '<S23>/Constant'
   */
  Torque_Control_ESP32_V6_B.Compare_h2 = Torque_Control_ESP32_V6_B.Mean1 >=
    Torque_Control_ESP32_V6_P.CompareToConstant3_const;

  /* Logic: '<S18>/AND1' */
  Torque_Control_ESP32_V6_B.AND1 = Torque_Control_ESP32_V6_B.Compare_c &&
    Torque_Control_ESP32_V6_B.Compare_h2;

  /* Switch: '<S18>/Switch' */
  if (Torque_Control_ESP32_V6_B.AND) {
    /* Switch: '<S18>/Switch' */
    Torque_Control_ESP32_V6_B.Switch = Torque_Control_ESP32_V6_B.Mean;
  } else {
    /* Switch: '<S18>/Switch' incorporates:
     *  Constant: '<S18>/Constant'
     */
    Torque_Control_ESP32_V6_B.Switch = (real32_T)
      Torque_Control_ESP32_V6_P.Constant_Value_f;
  }

  /* End of Switch: '<S18>/Switch' */

  /* RelationalOperator: '<S25>/Compare' incorporates:
   *  Constant: '<S25>/Constant'
   */
  Torque_Control_ESP32_V6_B.Compare_d = Torque_Control_ESP32_V6_B.Switch >
    Torque_Control_ESP32_V6_P.CompareToConstant5_const;

  /* Logic: '<S19>/NOT1' */
  Torque_Control_ESP32_V6_B.NOT1 = !(Torque_Control_ESP32_V6_B.Switch4 != 0.0F);

  /* Switch: '<S19>/Switch1' incorporates:
   *  Constant: '<S6>/AnlgBrkPrsnt'
   */
  if (Torque_Control_ESP32_V6_P.AnlgBrkPrsnt_Value >
      Torque_Control_ESP32_V6_P.Switch1_Threshold_f) {
    /* Switch: '<S19>/Switch1' incorporates:
     *  Constant: '<S6>/brkdefault'
     */
    Torque_Control_ESP32_V6_B.Switch1_p =
      Torque_Control_ESP32_V6_P.brkdefault_Value;
  } else {
    /* Switch: '<S19>/Switch1' */
    Torque_Control_ESP32_V6_B.Switch1_p = Torque_Control_ESP32_V6_B.Switch1_b;
  }

  /* End of Switch: '<S19>/Switch1' */

  /* Logic: '<S19>/NOT2' */
  Torque_Control_ESP32_V6_B.NOT2 = !(Torque_Control_ESP32_V6_B.Switch1_p != 0.0F);

  /* Logic: '<S19>/AND1' */
  Torque_Control_ESP32_V6_B.AND1_g = Torque_Control_ESP32_V6_B.NOT1 &&
    Torque_Control_ESP32_V6_B.NOT2;

  /* RelationalOperator: '<S26>/Compare' incorporates:
   *  Constant: '<S26>/Constant'
   */
  Torque_Control_ESP32_V6_B.Compare_o = Torque_Control_ESP32_V6_B.AND1_g ==
    Torque_Control_ESP32_V6_P.CompareToConstant6_const;

  /* Logic: '<S18>/AND2' */
  Torque_Control_ESP32_V6_B.AND2 = Torque_Control_ESP32_V6_B.Compare_d &&
    Torque_Control_ESP32_V6_B.Compare_o;

  /* Switch: '<S18>/Switch1' */
  if (Torque_Control_ESP32_V6_B.AND1) {
    /* Switch: '<S18>/Switch1' */
    Torque_Control_ESP32_V6_B.Switch1_a = Torque_Control_ESP32_V6_B.Mean1;
  } else {
    /* Switch: '<S18>/Switch1' incorporates:
     *  Constant: '<S18>/Constant2'
     */
    Torque_Control_ESP32_V6_B.Switch1_a = (real32_T)
      Torque_Control_ESP32_V6_P.Constant2_Value_g;
  }

  /* End of Switch: '<S18>/Switch1' */

  /* Sum: '<S18>/Add2' */
  Torque_Control_ESP32_V6_B.Add2 = Torque_Control_ESP32_V6_B.Switch -
    Torque_Control_ESP32_V6_B.Switch1_a;

  /* Abs: '<S18>/Abs' */
  Torque_Control_ESP32_V6_B.Abs = (real32_T)fabs(Torque_Control_ESP32_V6_B.Add2);

  /* RelationalOperator: '<S24>/Compare' incorporates:
   *  Constant: '<S24>/Constant'
   */
  Torque_Control_ESP32_V6_B.Compare_i = Torque_Control_ESP32_V6_B.Abs >
    Torque_Control_ESP32_V6_P.CompareToConstant4_const;

  /* Sum: '<S31>/FixPt Sum1' incorporates:
   *  Constant: '<S31>/FixPt Constant'
   */
  Torque_Control_ESP32_V6_B.FixPtSum1 = (uint8_T)((uint32_T)
    Torque_Control_ESP32_V6_B.Output +
    Torque_Control_ESP32_V6_P.FixPtConstant_Value);

  /* Switch: '<S32>/FixPt Switch' */
  if (Torque_Control_ESP32_V6_B.FixPtSum1 >
      Torque_Control_ESP32_V6_P.WrapToZero_Threshold) {
    /* Switch: '<S32>/FixPt Switch' incorporates:
     *  Constant: '<S32>/Constant'
     */
    Torque_Control_ESP32_V6_B.FixPtSwitch =
      Torque_Control_ESP32_V6_P.Constant_Value_c;
  } else {
    /* Switch: '<S32>/FixPt Switch' */
    Torque_Control_ESP32_V6_B.FixPtSwitch = Torque_Control_ESP32_V6_B.FixPtSum1;
  }

  /* End of Switch: '<S32>/FixPt Switch' */

  /* Sum: '<S33>/FixPt Sum1' incorporates:
   *  Constant: '<S33>/FixPt Constant'
   */
  Torque_Control_ESP32_V6_B.FixPtSum1_b = (uint8_T)((uint32_T)
    Torque_Control_ESP32_V6_B.Output_p +
    Torque_Control_ESP32_V6_P.FixPtConstant_Value_g);

  /* Switch: '<S34>/FixPt Switch' */
  if (Torque_Control_ESP32_V6_B.FixPtSum1_b >
      Torque_Control_ESP32_V6_P.WrapToZero_Threshold_b) {
    /* Switch: '<S34>/FixPt Switch' incorporates:
     *  Constant: '<S34>/Constant'
     */
    Torque_Control_ESP32_V6_B.FixPtSwitch_o =
      Torque_Control_ESP32_V6_P.Constant_Value_o;
  } else {
    /* Switch: '<S34>/FixPt Switch' */
    Torque_Control_ESP32_V6_B.FixPtSwitch_o =
      Torque_Control_ESP32_V6_B.FixPtSum1_b;
  }

  /* End of Switch: '<S34>/FixPt Switch' */

  /* Logic: '<S18>/NOT' */
  Torque_Control_ESP32_V6_B.NOT = !Torque_Control_ESP32_V6_B.AND2;

  /* Switch: '<S18>/Switch2' */
  if (Torque_Control_ESP32_V6_B.NOT) {
    /* Switch: '<S18>/Switch2' */
    Torque_Control_ESP32_V6_B.Switch2 = Torque_Control_ESP32_V6_B.Switch;
  } else {
    /* Switch: '<S18>/Switch2' incorporates:
     *  Constant: '<S18>/Constant4'
     */
    Torque_Control_ESP32_V6_B.Switch2 = (real32_T)
      Torque_Control_ESP32_V6_P.Constant4_Value_d;
  }

  /* End of Switch: '<S18>/Switch2' */

  /* Logic: '<S6>/NOT' */
  Torque_Control_ESP32_V6_B.NOT_f = !(Torque_Control_ESP32_V6_B.RTD_st != 0.0F);

  /* Logic: '<S6>/Logical Operator' */
  Torque_Control_ESP32_V6_B.LogicalOperator =
    Torque_Control_ESP32_V6_B.Compare_i || Torque_Control_ESP32_V6_B.NOT_f;

  /* Update for UnitDelay: '<S29>/Output' */
  Torque_Control_ESP32_V6_DW.Output_DSTATE =
    Torque_Control_ESP32_V6_B.FixPtSwitch;

  /* Update for UnitDelay: '<S30>/Output' */
  Torque_Control_ESP32_V6_DW.Output_DSTATE_n =
    Torque_Control_ESP32_V6_B.FixPtSwitch_o;

  /* End of Outputs for S-Function (fcgen): '<Root>/Function-Call Generator3' */

  /* S-Function (fcgen): '<Root>/Function-Call Generator2' incorporates:
   *  SubSystem: '<Root>/Cooling'
   */
  /* Switch: '<S1>/Switch' */
  if (Torque_Control_ESP32_V6_B.Switch3 >
      Torque_Control_ESP32_V6_P.Switch_Threshold_m) {
    /* Switch: '<S1>/Switch' incorporates:
     *  Constant: '<S1>/Constant'
     */
    Torque_Control_ESP32_V6_B.Switch_a =
      Torque_Control_ESP32_V6_P.Constant_Value_i != 0.0F;
  } else {
    /* Switch: '<S1>/Switch' incorporates:
     *  Constant: '<S1>/Constant1'
     */
    Torque_Control_ESP32_V6_B.Switch_a =
      Torque_Control_ESP32_V6_P.Constant1_Value_i != 0.0F;
  }

  /* End of Switch: '<S1>/Switch' */
  /* End of Outputs for S-Function (fcgen): '<Root>/Function-Call Generator2' */

  /* S-Function (fcgen): '<Root>/Function-Call Generator6' incorporates:
   *  SubSystem: '<Root>/GearShift'
   */
  /* RelationalOperator: '<S9>/Compare' incorporates:
   *  Constant: '<S9>/Constant'
   */
  Torque_Control_ESP32_V6_B.Compare = Torque_Control_ESP32_V6_B.Switch7 >
    Torque_Control_ESP32_V6_P.CompareToConstant_const_a;

  /* DiscretePulseGenerator: '<S4>/Pulse Generator1' */
  Torque_Control_ESP32_V6_B.PulseGenerator1 =
    Torque_Control_ESP32_V6_DW.clockTickCounter <
    Torque_Control_ESP32_V6_P.PulseGenerator1_Duty &&
    Torque_Control_ESP32_V6_DW.clockTickCounter >= 0 ?
    Torque_Control_ESP32_V6_P.PulseGenerator1_Amp : 0.0;

  /* DiscretePulseGenerator: '<S4>/Pulse Generator1' */
  if (Torque_Control_ESP32_V6_DW.clockTickCounter >=
      Torque_Control_ESP32_V6_P.PulseGenerator1_Period - 1.0) {
    Torque_Control_ESP32_V6_DW.clockTickCounter = 0;
  } else {
    Torque_Control_ESP32_V6_DW.clockTickCounter++;
  }

  /* Switch: '<S4>/Switch' */
  if (Torque_Control_ESP32_V6_B.Compare) {
    /* Switch: '<S4>/Switch' */
    Torque_Control_ESP32_V6_B.Switch_i =
      Torque_Control_ESP32_V6_B.PulseGenerator1 != 0.0;
  } else {
    /* Switch: '<S4>/Switch' incorporates:
     *  Constant: '<S4>/Constant'
     */
    Torque_Control_ESP32_V6_B.Switch_i =
      Torque_Control_ESP32_V6_P.Constant_Value_ij != 0.0F;
  }

  /* End of Switch: '<S4>/Switch' */
  /* End of Outputs for S-Function (fcgen): '<Root>/Function-Call Generator6' */

  /* S-Function (fcgen): '<Root>/Function-Call Generator4' incorporates:
   *  SubSystem: '<Root>/PowerTrain'
   */
  /* Switch: '<S5>/Switch1' incorporates:
   *  Constant: '<S5>/VehSpeedPrsnt'
   */
  if (Torque_Control_ESP32_V6_P.VehSpeedPrsnt_Value >
      Torque_Control_ESP32_V6_P.Switch1_Threshold_e) {
    /* Product: '<S5>/Divide3' incorporates:
     *  Constant: '<S5>/TransmRat'
     */
    Torque_Control_ESP32_V6_B.Divide3 = Torque_Control_ESP32_V6_B.Switch7 /
      Torque_Control_ESP32_V6_P.TransmRat_Value;

    /* Product: '<S5>/Divide' incorporates:
     *  Constant: '<S5>/sec'
     */
    Torque_Control_ESP32_V6_B.Divide_m = Torque_Control_ESP32_V6_B.Divide3 /
      Torque_Control_ESP32_V6_P.sec_Value_e;

    /* Product: '<S5>/Divide1' incorporates:
     *  Constant: '<S5>/sec1'
     */
    Torque_Control_ESP32_V6_B.Divide1_j = Torque_Control_ESP32_V6_B.Divide_m *
      Torque_Control_ESP32_V6_P.sec1_Value_o;

    /* Switch: '<S5>/Switch1' */
    Torque_Control_ESP32_V6_B.Switch1 = Torque_Control_ESP32_V6_B.Divide1_j;
  } else {
    /* Switch: '<S5>/Switch1' */
    Torque_Control_ESP32_V6_B.Switch1 = Torque_Control_ESP32_V6_B.Switch8;
  }

  /* End of Switch: '<S5>/Switch1' */

  /* SwitchCase: '<S5>/Switch Case1' */
  den = Torque_Control_ESP32_V6_B.Switch_h;
  if (den < 0.0F) {
    den = (real32_T)ceil(den);
  } else {
    den = (real32_T)floor(den);
  }

  if (rtIsNaNF(den) || rtIsInfF(den)) {
    den = 0.0F;
  } else {
    den = (real32_T)fmod(den, 4.294967296E+9);
  }

  switch (den < 0.0F ? -(int32_T)(uint32_T)-den : (int32_T)(uint32_T)den) {
   case 0:
    /* Outputs for IfAction SubSystem: '<S5>/NormalMode' incorporates:
     *  ActionPort: '<S12>/Action Port'
     */
    /* Merge: '<S5>/Merge' incorporates:
     *  Lookup_n-D: '<S12>/NormalMode'
     *  Switch: '<S18>/Switch2'
     *  Switch: '<S5>/Switch1'
     */
    Torque_Control_ESP32_V6_B.Merge = look2_iflf_linlcapw
      (Torque_Control_ESP32_V6_B.Switch2, Torque_Control_ESP32_V6_B.Switch1,
       Torque_Control_ESP32_V6_P.NormalMode_bp01Data,
       Torque_Control_ESP32_V6_P.NormalMode_bp02Data,
       Torque_Control_ESP32_V6_P.NormalMode_tableData,
       Torque_Control_ESP32_V6_P.NormalMode_maxIndex, 11U);

    /* End of Outputs for SubSystem: '<S5>/NormalMode' */
    break;

   case 1:
    /* Outputs for IfAction SubSystem: '<S5>/SportMode' incorporates:
     *  ActionPort: '<S14>/Action Port'
     */
    /* Merge: '<S5>/Merge' incorporates:
     *  Lookup_n-D: '<S14>/SportMode'
     *  Switch: '<S18>/Switch2'
     *  Switch: '<S5>/Switch1'
     */
    Torque_Control_ESP32_V6_B.Merge = look2_iflf_linlcapw
      (Torque_Control_ESP32_V6_B.Switch2, Torque_Control_ESP32_V6_B.Switch1,
       Torque_Control_ESP32_V6_P.SportMode_bp01Data,
       Torque_Control_ESP32_V6_P.SportMode_bp02Data,
       Torque_Control_ESP32_V6_P.SportMode_tableData,
       Torque_Control_ESP32_V6_P.SportMode_maxIndex, 11U);

    /* End of Outputs for SubSystem: '<S5>/SportMode' */
    break;

   case 2:
    /* Outputs for IfAction SubSystem: '<S5>/EcoMode' incorporates:
     *  ActionPort: '<S11>/Action Port'
     */
    /* Merge: '<S5>/Merge' incorporates:
     *  Lookup_n-D: '<S11>/EcoMode'
     *  Switch: '<S18>/Switch2'
     *  Switch: '<S5>/Switch1'
     */
    Torque_Control_ESP32_V6_B.Merge = look2_iflf_linlcapw
      (Torque_Control_ESP32_V6_B.Switch2, Torque_Control_ESP32_V6_B.Switch1,
       Torque_Control_ESP32_V6_P.EcoMode_bp01Data,
       Torque_Control_ESP32_V6_P.EcoMode_bp02Data,
       Torque_Control_ESP32_V6_P.EcoMode_tableData,
       Torque_Control_ESP32_V6_P.EcoMode_maxIndex, 11U);

    /* End of Outputs for SubSystem: '<S5>/EcoMode' */
    break;

   default:
    /* Outputs for IfAction SubSystem: '<S5>/Defalut' incorporates:
     *  ActionPort: '<S10>/Action Port'
     */
    /* Merge: '<S5>/Merge' incorporates:
     *  Constant: '<S10>/Constant'
     *  SignalConversion generated from: '<S10>/Out1'
     */
    Torque_Control_ESP32_V6_B.Merge = Torque_Control_ESP32_V6_P.Constant_Value_d;

    /* End of Outputs for SubSystem: '<S5>/Defalut' */
    break;
  }

  /* End of SwitchCase: '<S5>/Switch Case1' */
  /* End of Outputs for S-Function (fcgen): '<Root>/Function-Call Generator4' */

  /* S-Function (fcgen): '<Root>/Function-Call Generator' incorporates:
   *  SubSystem: '<Root>/DataTransmission'
   */
  /* MATLABSystem: '<S3>/Digital Output2' */
  writeDigitalPin(32, (uint8_T)Torque_Control_ESP32_V6_B.LogicalOperator);

  /* MATLABSystem: '<S3>/Digital Output1' */
  writeDigitalPin(33, (uint8_T)Torque_Control_ESP32_V6_B.Switch_a);

  /* MATLABSystem: '<S3>/Digital Output' */
  writeDigitalPin(2, (uint8_T)Torque_Control_ESP32_V6_B.Switch_i);

  /* End of Outputs for S-Function (fcgen): '<Root>/Function-Call Generator' */
}

/* Model initialize function */
void Torque_Control_ESP32_V6_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize error status */
  rtmSetErrorStatus(Torque_Control_ESP32_V6_M, (NULL));

  /* block I/O */
  (void) memset(((void *) &Torque_Control_ESP32_V6_B), 0,
                sizeof(B_Torque_Control_ESP32_V6_T));

  /* states (dwork) */
  (void) memset((void *)&Torque_Control_ESP32_V6_DW, 0,
                sizeof(DW_Torque_Control_ESP32_V6_T));

  {
    int32_T i;
    Torque_Control_ESP32_V6_PrevZCX.TriggeredSubsystem_Trig_ZCE =
      UNINITIALIZED_ZCSIG;

    /* SystemInitialize for S-Function (fcgen): '<Root>/Function-Call Generator1' incorporates:
     *  SubSystem: '<Root>/DataAcquisition'
     */
    /* InitializeConditions for Delay: '<S2>/Delay1' */
    for (i = 0; i < 15; i++) {
      Torque_Control_ESP32_V6_DW.Delay1_DSTATE[i] =
        Torque_Control_ESP32_V6_P.Delay1_InitialCondition;
    }

    /* End of InitializeConditions for Delay: '<S2>/Delay1' */

    /* InitializeConditions for Delay: '<S2>/Delay' */
    Torque_Control_ESP32_V6_DW.Delay_DSTATE[0] =
      Torque_Control_ESP32_V6_P.Delay_InitialCondition;
    Torque_Control_ESP32_V6_DW.Delay_DSTATE[1] =
      Torque_Control_ESP32_V6_P.Delay_InitialCondition;

    /* SystemInitialize for Triggered SubSystem: '<S2>/Triggered Subsystem' */
    /* SystemInitialize for Switch: '<S7>/Switch' incorporates:
     *  Outport: '<S7>/DrvMode_st'
     */
    Torque_Control_ESP32_V6_B.Switch_h = Torque_Control_ESP32_V6_P.DrvMode_st_Y0;

    /* End of SystemInitialize for SubSystem: '<S2>/Triggered Subsystem' */

    /* Start for MATLABSystem: '<S2>/Analog Input4' */
    Torque_Control_ESP32_V6_DW.obj_ac.matlabCodegenIsDeleted = false;
    Torque_Control_ESP32_V6_DW.objisempty_n = true;
    Torque_Control_ESP32_V6_DW.obj_ac.SampleTime =
      Torque_Control_ESP32_V6_P.AnalogInput4_SampleTime;
    Torque_Control_ESP32_V6_DW.obj_ac.isInitialized = 1;
    Torque_Control_ESP32_V6_DW.obj_ac.AnalogInDriverObj.MW_ANALOGIN_HANDLE =
      MW_AnalogInSingle_Open(36U);
    Torque_Control_ESP32_V6_DW.obj_ac.isSetupComplete = true;

    /* Start for MATLABSystem: '<S2>/Analog Input5' */
    Torque_Control_ESP32_V6_DW.obj_a.matlabCodegenIsDeleted = false;
    Torque_Control_ESP32_V6_DW.objisempty_d = true;
    Torque_Control_ESP32_V6_DW.obj_a.SampleTime =
      Torque_Control_ESP32_V6_P.AnalogInput5_SampleTime;
    Torque_Control_ESP32_V6_DW.obj_a.isInitialized = 1;
    Torque_Control_ESP32_V6_DW.obj_a.AnalogInDriverObj.MW_ANALOGIN_HANDLE =
      MW_AnalogInSingle_Open(39U);
    Torque_Control_ESP32_V6_DW.obj_a.isSetupComplete = true;

    /* Start for MATLABSystem: '<S2>/Digital Input' */
    Torque_Control_ESP32_V6_DW.obj_ny.matlabCodegenIsDeleted = false;
    Torque_Control_ESP32_V6_DW.objisempty_a = true;
    Torque_Control_ESP32_V6_DW.obj_ny.SampleTime =
      Torque_Control_ESP32_V6_P.DigitalInput_SampleTime;
    Torque_Control_ESP32_V6_DW.obj_ny.isInitialized = 1;
    digitalIOSetup(25, 0);
    Torque_Control_ESP32_V6_DW.obj_ny.isSetupComplete = true;

    /* Start for MATLABSystem: '<S2>/Analog Input7' */
    Torque_Control_ESP32_V6_DW.obj.matlabCodegenIsDeleted = false;
    Torque_Control_ESP32_V6_DW.objisempty_e = true;
    Torque_Control_ESP32_V6_DW.obj.SampleTime =
      Torque_Control_ESP32_V6_P.AnalogInput7_SampleTime;
    Torque_Control_ESP32_V6_DW.obj.isInitialized = 1;
    Torque_Control_ESP32_V6_DW.obj.AnalogInDriverObj.MW_ANALOGIN_HANDLE =
      MW_AnalogInSingle_Open(35U);
    Torque_Control_ESP32_V6_DW.obj.isSetupComplete = true;

    /* Start for MATLABSystem: '<S2>/Digital Input1' */
    Torque_Control_ESP32_V6_DW.obj_g.matlabCodegenIsDeleted = false;
    Torque_Control_ESP32_V6_DW.objisempty_g = true;
    Torque_Control_ESP32_V6_DW.obj_g.SampleTime =
      Torque_Control_ESP32_V6_P.DigitalInput1_SampleTime;
    Torque_Control_ESP32_V6_DW.obj_g.isInitialized = 1;
    digitalIOSetup(26, 0);
    Torque_Control_ESP32_V6_DW.obj_g.isSetupComplete = true;

    /* Start for MATLABSystem: '<S2>/Digital Input2' */
    Torque_Control_ESP32_V6_DW.obj_n.matlabCodegenIsDeleted = false;
    Torque_Control_ESP32_V6_DW.objisempty_l = true;
    Torque_Control_ESP32_V6_DW.obj_n.SampleTime =
      Torque_Control_ESP32_V6_P.DigitalInput2_SampleTime;
    Torque_Control_ESP32_V6_DW.obj_n.isInitialized = 1;
    digitalIOSetup(27, 0);
    Torque_Control_ESP32_V6_DW.obj_n.isSetupComplete = true;

    /* Start for MATLABSystem: '<S2>/Analog Input1' */
    Torque_Control_ESP32_V6_DW.obj_h.matlabCodegenIsDeleted = false;
    Torque_Control_ESP32_V6_DW.objisempty_nl = true;
    Torque_Control_ESP32_V6_DW.obj_h.SampleTime =
      Torque_Control_ESP32_V6_P.AnalogInput1_SampleTime;
    Torque_Control_ESP32_V6_DW.obj_h.isInitialized = 1;
    Torque_Control_ESP32_V6_DW.obj_h.AnalogInDriverObj.MW_ANALOGIN_HANDLE =
      MW_AnalogInSingle_Open(14U);
    Torque_Control_ESP32_V6_DW.obj_h.isSetupComplete = true;

    /* Start for MATLABSystem: '<S2>/Digital Input3' */
    Torque_Control_ESP32_V6_DW.obj_c.matlabCodegenIsDeleted = false;
    Torque_Control_ESP32_V6_DW.objisempty_m = true;
    Torque_Control_ESP32_V6_DW.obj_c.SampleTime =
      Torque_Control_ESP32_V6_P.DigitalInput3_SampleTime;
    Torque_Control_ESP32_V6_DW.obj_c.isInitialized = 1;
    digitalIOSetup(4, 0);
    Torque_Control_ESP32_V6_DW.obj_c.isSetupComplete = true;

    /* Start for MATLABSystem: '<S2>/Analog Input6' */
    Torque_Control_ESP32_V6_DW.obj_j.matlabCodegenIsDeleted = false;
    Torque_Control_ESP32_V6_DW.objisempty_j = true;
    Torque_Control_ESP32_V6_DW.obj_j.SampleTime =
      Torque_Control_ESP32_V6_P.AnalogInput6_SampleTime;
    Torque_Control_ESP32_V6_DW.obj_j.isInitialized = 1;
    Torque_Control_ESP32_V6_DW.obj_j.AnalogInDriverObj.MW_ANALOGIN_HANDLE =
      MW_AnalogInSingle_Open(34U);
    Torque_Control_ESP32_V6_DW.obj_j.isSetupComplete = true;

    /* Start for MATLABSystem: '<S2>/Digital Input4' */
    Torque_Control_ESP32_V6_DW.obj_p.matlabCodegenIsDeleted = false;
    Torque_Control_ESP32_V6_DW.objisempty = true;
    Torque_Control_ESP32_V6_DW.obj_p.SampleTime =
      Torque_Control_ESP32_V6_P.DigitalInput4_SampleTime;
    Torque_Control_ESP32_V6_DW.obj_p.isInitialized = 1;
    digitalIOSetup(5, 0);
    Torque_Control_ESP32_V6_DW.obj_p.isSetupComplete = true;

    /* SystemInitialize for Switch: '<S2>/Switch' incorporates:
     *  Outport: '<S2>/AccPed01'
     */
    Torque_Control_ESP32_V6_B.AccPed01 = Torque_Control_ESP32_V6_P.AccPed01_Y0;

    /* SystemInitialize for Switch: '<S2>/Switch2' incorporates:
     *  Outport: '<S2>/AccPed02'
     */
    Torque_Control_ESP32_V6_B.AccPed02 = Torque_Control_ESP32_V6_P.AccPed02_Y0;

    /* SystemInitialize for Switch: '<S2>/Switch4' incorporates:
     *  Outport: '<S2>/BrkPedDig_st'
     */
    Torque_Control_ESP32_V6_B.Switch4 =
      Torque_Control_ESP32_V6_P.BrkPedDig_st_Y0;

    /* SystemInitialize for Switch: '<S2>/Switch1' incorporates:
     *  Outport: '<S2>/BrkPedAnlg'
     */
    Torque_Control_ESP32_V6_B.Switch1_b =
      Torque_Control_ESP32_V6_P.BrkPedAnlg_Y0;

    /* SystemInitialize for Switch: '<S2>/Switch5' incorporates:
     *  Outport: '<S2>/RTD_st'
     */
    Torque_Control_ESP32_V6_B.RTD_st = Torque_Control_ESP32_V6_P.RTD_st_Y0;

    /* SystemInitialize for Switch: '<S2>/Switch7' incorporates:
     *  Outport: '<S2>/AxelRpm'
     */
    Torque_Control_ESP32_V6_B.Switch7 = Torque_Control_ESP32_V6_P.AxelRpm_Y0;

    /* SystemInitialize for Switch: '<S2>/Switch8' incorporates:
     *  Outport: '<S2>/VehSpeed'
     */
    Torque_Control_ESP32_V6_B.Switch8 = Torque_Control_ESP32_V6_P.VehSpeed_Y0;

    /* SystemInitialize for Switch: '<S2>/Switch3' incorporates:
     *  Outport: '<S2>/TempSensr'
     */
    Torque_Control_ESP32_V6_B.Switch3 = Torque_Control_ESP32_V6_P.TempSensr_Y0;

    /* End of SystemInitialize for S-Function (fcgen): '<Root>/Function-Call Generator1' */

    /* SystemInitialize for S-Function (fcgen): '<Root>/Function-Call Generator3' incorporates:
     *  SubSystem: '<Root>/SafetyCheck'
     */
    /* InitializeConditions for UnitDelay: '<S29>/Output' */
    Torque_Control_ESP32_V6_DW.Output_DSTATE =
      Torque_Control_ESP32_V6_P.Output_InitialCondition;

    /* InitializeConditions for S-Function (sdspstatfcns): '<S18>/Mean' */
    Torque_Control_ESP32_V6_DW.Mean_Iteration = 0U;
    Torque_Control_ESP32_V6_DW.Mean_AccVal = 0.0F;

    /* InitializeConditions for UnitDelay: '<S30>/Output' */
    Torque_Control_ESP32_V6_DW.Output_DSTATE_n =
      Torque_Control_ESP32_V6_P.Output_InitialCondition_o;

    /* InitializeConditions for S-Function (sdspstatfcns): '<S18>/Mean1' */
    Torque_Control_ESP32_V6_DW.Mean1_Iteration = 0U;
    Torque_Control_ESP32_V6_DW.Mean1_AccVal = 0.0F;

    /* SystemInitialize for Logic: '<S6>/Logical Operator' incorporates:
     *  Outport: '<S6>/Fault_st'
     */
    Torque_Control_ESP32_V6_B.LogicalOperator =
      Torque_Control_ESP32_V6_P.Fault_st_Y0;

    /* SystemInitialize for Switch: '<S18>/Switch2' incorporates:
     *  Outport: '<S6>/AccPedReq'
     */
    Torque_Control_ESP32_V6_B.Switch2 = Torque_Control_ESP32_V6_P.AccPedReq_Y0;

    /* End of SystemInitialize for S-Function (fcgen): '<Root>/Function-Call Generator3' */

    /* SystemInitialize for S-Function (fcgen): '<Root>/Function-Call Generator2' incorporates:
     *  SubSystem: '<Root>/Cooling'
     */
    /* SystemInitialize for Switch: '<S1>/Switch' incorporates:
     *  Outport: '<S1>/FanReq'
     */
    Torque_Control_ESP32_V6_B.Switch_a = Torque_Control_ESP32_V6_P.FanReq_Y0;

    /* End of SystemInitialize for S-Function (fcgen): '<Root>/Function-Call Generator2' */

    /* SystemInitialize for S-Function (fcgen): '<Root>/Function-Call Generator6' incorporates:
     *  SubSystem: '<Root>/GearShift'
     */
    /* InitializeConditions for DiscretePulseGenerator: '<S4>/Pulse Generator1' */
    Torque_Control_ESP32_V6_DW.clockTickCounter = 0;

    /* SystemInitialize for Switch: '<S4>/Switch' incorporates:
     *  Outport: '<S4>/LED01'
     */
    Torque_Control_ESP32_V6_B.Switch_i = Torque_Control_ESP32_V6_P.LED01_Y0;

    /* End of SystemInitialize for S-Function (fcgen): '<Root>/Function-Call Generator6' */

    /* SystemInitialize for S-Function (fcgen): '<Root>/Function-Call Generator4' incorporates:
     *  SubSystem: '<Root>/PowerTrain'
     */
    /* SystemInitialize for Merge: '<S5>/Merge' */
    Torque_Control_ESP32_V6_B.Merge =
      Torque_Control_ESP32_V6_P.Merge_InitialOutput;

    /* End of SystemInitialize for S-Function (fcgen): '<Root>/Function-Call Generator4' */

    /* SystemInitialize for S-Function (fcgen): '<Root>/Function-Call Generator' incorporates:
     *  SubSystem: '<Root>/DataTransmission'
     */
    /* Start for MATLABSystem: '<S3>/Digital Output2' */
    Torque_Control_ESP32_V6_DW.obj_d.matlabCodegenIsDeleted = false;
    Torque_Control_ESP32_V6_DW.objisempty_c = true;
    Torque_Control_ESP32_V6_DW.obj_d.isInitialized = 1;
    digitalIOSetup(32, 1);
    Torque_Control_ESP32_V6_DW.obj_d.isSetupComplete = true;

    /* Start for MATLABSystem: '<S3>/Digital Output1' */
    Torque_Control_ESP32_V6_DW.obj_o.matlabCodegenIsDeleted = false;
    Torque_Control_ESP32_V6_DW.objisempty_f = true;
    Torque_Control_ESP32_V6_DW.obj_o.isInitialized = 1;
    digitalIOSetup(33, 1);
    Torque_Control_ESP32_V6_DW.obj_o.isSetupComplete = true;

    /* Start for MATLABSystem: '<S3>/Digital Output' */
    Torque_Control_ESP32_V6_DW.obj_ds.matlabCodegenIsDeleted = false;
    Torque_Control_ESP32_V6_DW.objisempty_fg = true;
    Torque_Control_ESP32_V6_DW.obj_ds.isInitialized = 1;
    digitalIOSetup(2, 1);
    Torque_Control_ESP32_V6_DW.obj_ds.isSetupComplete = true;

    /* End of SystemInitialize for S-Function (fcgen): '<Root>/Function-Call Generator' */
  }
}

/* Model terminate function */
void Torque_Control_ESP32_V6_terminate(void)
{
  /* Terminate for S-Function (fcgen): '<Root>/Function-Call Generator1' incorporates:
   *  SubSystem: '<Root>/DataAcquisition'
   */
  /* Terminate for MATLABSystem: '<S2>/Analog Input4' */
  if (!Torque_Control_ESP32_V6_DW.obj_ac.matlabCodegenIsDeleted) {
    Torque_Control_ESP32_V6_DW.obj_ac.matlabCodegenIsDeleted = true;
    if (Torque_Control_ESP32_V6_DW.obj_ac.isInitialized == 1 &&
        Torque_Control_ESP32_V6_DW.obj_ac.isSetupComplete) {
      Torque_Control_ESP32_V6_DW.obj_ac.AnalogInDriverObj.MW_ANALOGIN_HANDLE =
        MW_AnalogIn_GetHandle(36U);
      MW_AnalogIn_Close
        (Torque_Control_ESP32_V6_DW.obj_ac.AnalogInDriverObj.MW_ANALOGIN_HANDLE);
    }
  }

  /* End of Terminate for MATLABSystem: '<S2>/Analog Input4' */

  /* Terminate for MATLABSystem: '<S2>/Analog Input5' */
  if (!Torque_Control_ESP32_V6_DW.obj_a.matlabCodegenIsDeleted) {
    Torque_Control_ESP32_V6_DW.obj_a.matlabCodegenIsDeleted = true;
    if (Torque_Control_ESP32_V6_DW.obj_a.isInitialized == 1 &&
        Torque_Control_ESP32_V6_DW.obj_a.isSetupComplete) {
      Torque_Control_ESP32_V6_DW.obj_a.AnalogInDriverObj.MW_ANALOGIN_HANDLE =
        MW_AnalogIn_GetHandle(39U);
      MW_AnalogIn_Close
        (Torque_Control_ESP32_V6_DW.obj_a.AnalogInDriverObj.MW_ANALOGIN_HANDLE);
    }
  }

  /* End of Terminate for MATLABSystem: '<S2>/Analog Input5' */

  /* Terminate for MATLABSystem: '<S2>/Digital Input' */
  if (!Torque_Control_ESP32_V6_DW.obj_ny.matlabCodegenIsDeleted) {
    Torque_Control_ESP32_V6_DW.obj_ny.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<S2>/Digital Input' */

  /* Terminate for MATLABSystem: '<S2>/Analog Input7' */
  if (!Torque_Control_ESP32_V6_DW.obj.matlabCodegenIsDeleted) {
    Torque_Control_ESP32_V6_DW.obj.matlabCodegenIsDeleted = true;
    if (Torque_Control_ESP32_V6_DW.obj.isInitialized == 1 &&
        Torque_Control_ESP32_V6_DW.obj.isSetupComplete) {
      Torque_Control_ESP32_V6_DW.obj.AnalogInDriverObj.MW_ANALOGIN_HANDLE =
        MW_AnalogIn_GetHandle(35U);
      MW_AnalogIn_Close
        (Torque_Control_ESP32_V6_DW.obj.AnalogInDriverObj.MW_ANALOGIN_HANDLE);
    }
  }

  /* End of Terminate for MATLABSystem: '<S2>/Analog Input7' */

  /* Terminate for MATLABSystem: '<S2>/Digital Input1' */
  if (!Torque_Control_ESP32_V6_DW.obj_g.matlabCodegenIsDeleted) {
    Torque_Control_ESP32_V6_DW.obj_g.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<S2>/Digital Input1' */

  /* Terminate for MATLABSystem: '<S2>/Digital Input2' */
  if (!Torque_Control_ESP32_V6_DW.obj_n.matlabCodegenIsDeleted) {
    Torque_Control_ESP32_V6_DW.obj_n.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<S2>/Digital Input2' */

  /* Terminate for MATLABSystem: '<S2>/Analog Input1' */
  if (!Torque_Control_ESP32_V6_DW.obj_h.matlabCodegenIsDeleted) {
    Torque_Control_ESP32_V6_DW.obj_h.matlabCodegenIsDeleted = true;
    if (Torque_Control_ESP32_V6_DW.obj_h.isInitialized == 1 &&
        Torque_Control_ESP32_V6_DW.obj_h.isSetupComplete) {
      Torque_Control_ESP32_V6_DW.obj_h.AnalogInDriverObj.MW_ANALOGIN_HANDLE =
        MW_AnalogIn_GetHandle(14U);
      MW_AnalogIn_Close
        (Torque_Control_ESP32_V6_DW.obj_h.AnalogInDriverObj.MW_ANALOGIN_HANDLE);
    }
  }

  /* End of Terminate for MATLABSystem: '<S2>/Analog Input1' */

  /* Terminate for MATLABSystem: '<S2>/Digital Input3' */
  if (!Torque_Control_ESP32_V6_DW.obj_c.matlabCodegenIsDeleted) {
    Torque_Control_ESP32_V6_DW.obj_c.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<S2>/Digital Input3' */

  /* Terminate for MATLABSystem: '<S2>/Analog Input6' */
  if (!Torque_Control_ESP32_V6_DW.obj_j.matlabCodegenIsDeleted) {
    Torque_Control_ESP32_V6_DW.obj_j.matlabCodegenIsDeleted = true;
    if (Torque_Control_ESP32_V6_DW.obj_j.isInitialized == 1 &&
        Torque_Control_ESP32_V6_DW.obj_j.isSetupComplete) {
      Torque_Control_ESP32_V6_DW.obj_j.AnalogInDriverObj.MW_ANALOGIN_HANDLE =
        MW_AnalogIn_GetHandle(34U);
      MW_AnalogIn_Close
        (Torque_Control_ESP32_V6_DW.obj_j.AnalogInDriverObj.MW_ANALOGIN_HANDLE);
    }
  }

  /* End of Terminate for MATLABSystem: '<S2>/Analog Input6' */

  /* Terminate for MATLABSystem: '<S2>/Digital Input4' */
  if (!Torque_Control_ESP32_V6_DW.obj_p.matlabCodegenIsDeleted) {
    Torque_Control_ESP32_V6_DW.obj_p.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<S2>/Digital Input4' */
  /* End of Terminate for S-Function (fcgen): '<Root>/Function-Call Generator1' */

  /* Terminate for S-Function (fcgen): '<Root>/Function-Call Generator' incorporates:
   *  SubSystem: '<Root>/DataTransmission'
   */
  /* Terminate for MATLABSystem: '<S3>/Digital Output2' */
  if (!Torque_Control_ESP32_V6_DW.obj_d.matlabCodegenIsDeleted) {
    Torque_Control_ESP32_V6_DW.obj_d.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<S3>/Digital Output2' */

  /* Terminate for MATLABSystem: '<S3>/Digital Output1' */
  if (!Torque_Control_ESP32_V6_DW.obj_o.matlabCodegenIsDeleted) {
    Torque_Control_ESP32_V6_DW.obj_o.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<S3>/Digital Output1' */

  /* Terminate for MATLABSystem: '<S3>/Digital Output' */
  if (!Torque_Control_ESP32_V6_DW.obj_ds.matlabCodegenIsDeleted) {
    Torque_Control_ESP32_V6_DW.obj_ds.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<S3>/Digital Output' */
  /* End of Terminate for S-Function (fcgen): '<Root>/Function-Call Generator' */
}
