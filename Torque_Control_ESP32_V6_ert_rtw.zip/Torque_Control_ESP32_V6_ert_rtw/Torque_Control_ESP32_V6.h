/*
 * Torque_Control_ESP32_V6.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Torque_Control_ESP32_V6".
 *
 * Model version              : 3.6
 * Simulink Coder version : 24.1 (R2024a) 19-Nov-2023
 * C source code generated on : Tue Sep 10 17:00:30 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef Torque_Control_ESP32_V6_h_
#define Torque_Control_ESP32_V6_h_
#ifndef Torque_Control_ESP32_V6_COMMON_INCLUDES_
#define Torque_Control_ESP32_V6_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "MW_arduino_digitalio.h"
#include "MW_AnalogIn.h"
#endif                            /* Torque_Control_ESP32_V6_COMMON_INCLUDES_ */

#include "MW_SVD.h"
#include <stddef.h>
#include <string.h>
#include "zero_crossing_types.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

/* Forward declaration for rtModel */
typedef struct tag_RTM_Torque_Control_ESP32__T RT_MODEL_Torque_Control_ESP32_T;

#ifndef struct_tag_9aqKbsbsI7JI0RwgnVwU0C
#define struct_tag_9aqKbsbsI7JI0RwgnVwU0C

struct tag_9aqKbsbsI7JI0RwgnVwU0C
{
  int32_T __dummy;
};

#endif                                 /* struct_tag_9aqKbsbsI7JI0RwgnVwU0C */

#ifndef typedef_b_arduinodriver_ArduinoDigita_T
#define typedef_b_arduinodriver_ArduinoDigita_T

typedef struct tag_9aqKbsbsI7JI0RwgnVwU0C b_arduinodriver_ArduinoDigita_T;

#endif                             /* typedef_b_arduinodriver_ArduinoDigita_T */

#ifndef struct_tag_qrLkTWTW64zZK0sqwALTyG
#define struct_tag_qrLkTWTW64zZK0sqwALTyG

struct tag_qrLkTWTW64zZK0sqwALTyG
{
  boolean_T matlabCodegenIsDeleted;
  int32_T isInitialized;
  boolean_T isSetupComplete;
  b_arduinodriver_ArduinoDigita_T DigitalIODriverObj;
};

#endif                                 /* struct_tag_qrLkTWTW64zZK0sqwALTyG */

#ifndef typedef_codertarget_arduinobase_block_T
#define typedef_codertarget_arduinobase_block_T

typedef struct tag_qrLkTWTW64zZK0sqwALTyG codertarget_arduinobase_block_T;

#endif                             /* typedef_codertarget_arduinobase_block_T */

/* Custom Type definition for MATLABSystem: '<S2>/Analog Input7' */
#include "MW_SVD.h"
#ifndef struct_tag_UTG5XI0vJCsmjbgura8BP
#define struct_tag_UTG5XI0vJCsmjbgura8BP

struct tag_UTG5XI0vJCsmjbgura8BP
{
  MW_Handle_Type MW_ANALOGIN_HANDLE;
};

#endif                                 /* struct_tag_UTG5XI0vJCsmjbgura8BP */

#ifndef typedef_g_arduinodriver_ArduinoAnalog_T
#define typedef_g_arduinodriver_ArduinoAnalog_T

typedef struct tag_UTG5XI0vJCsmjbgura8BP g_arduinodriver_ArduinoAnalog_T;

#endif                             /* typedef_g_arduinodriver_ArduinoAnalog_T */

#ifndef struct_tag_8ohiN1FAOgR98njPNu14NC
#define struct_tag_8ohiN1FAOgR98njPNu14NC

struct tag_8ohiN1FAOgR98njPNu14NC
{
  boolean_T matlabCodegenIsDeleted;
  int32_T isInitialized;
  boolean_T isSetupComplete;
  g_arduinodriver_ArduinoAnalog_T AnalogInDriverObj;
  real_T SampleTime;
};

#endif                                 /* struct_tag_8ohiN1FAOgR98njPNu14NC */

#ifndef typedef_codertarget_arduinobase_inter_T
#define typedef_codertarget_arduinobase_inter_T

typedef struct tag_8ohiN1FAOgR98njPNu14NC codertarget_arduinobase_inter_T;

#endif                             /* typedef_codertarget_arduinobase_inter_T */

#ifndef struct_tag_9aqKbsbsI7JI0RwgnVwU0C
#define struct_tag_9aqKbsbsI7JI0RwgnVwU0C

struct tag_9aqKbsbsI7JI0RwgnVwU0C
{
  int32_T __dummy;
};

#endif                                 /* struct_tag_9aqKbsbsI7JI0RwgnVwU0C */

#ifndef typedef_d_arduinodriver_ArduinoDigita_T
#define typedef_d_arduinodriver_ArduinoDigita_T

typedef struct tag_9aqKbsbsI7JI0RwgnVwU0C d_arduinodriver_ArduinoDigita_T;

#endif                             /* typedef_d_arduinodriver_ArduinoDigita_T */

#ifndef struct_tag_mPMPiw8t0JZKYO8orfnwRG
#define struct_tag_mPMPiw8t0JZKYO8orfnwRG

struct tag_mPMPiw8t0JZKYO8orfnwRG
{
  boolean_T matlabCodegenIsDeleted;
  int32_T isInitialized;
  boolean_T isSetupComplete;
  d_arduinodriver_ArduinoDigita_T DigitalIODriverObj;
  real_T SampleTime;
};

#endif                                 /* struct_tag_mPMPiw8t0JZKYO8orfnwRG */

#ifndef typedef_codertarget_arduinobase_blo_l_T
#define typedef_codertarget_arduinobase_blo_l_T

typedef struct tag_mPMPiw8t0JZKYO8orfnwRG codertarget_arduinobase_blo_l_T;

#endif                             /* typedef_codertarget_arduinobase_blo_l_T */

/* Block signals (default storage) */
typedef struct {
  real_T PulseGenerator1;              /* '<S4>/Pulse Generator1' */
  real_T Switch6;                      /* '<S2>/Switch6' */
  real_T Divide2;                      /* '<S2>/Divide2' */
  real_T Divide;                       /* '<S2>/Divide' */
  real_T Divide1;                      /* '<S2>/Divide1' */
  real_T Product;                      /* '<S2>/Product' */
  real32_T Switch1;                    /* '<S5>/Switch1' */
  real32_T Merge;                      /* '<S5>/Merge' */
  real32_T Divide3;                    /* '<S5>/Divide3' */
  real32_T Divide_m;                   /* '<S5>/Divide' */
  real32_T Divide1_j;                  /* '<S5>/Divide1' */
  real32_T Mean;                       /* '<S18>/Mean' */
  real32_T Mean1;                      /* '<S18>/Mean1' */
  real32_T Switch;                     /* '<S18>/Switch' */
  real32_T Switch1_p;                  /* '<S19>/Switch1' */
  real32_T Switch1_a;                  /* '<S18>/Switch1' */
  real32_T Add2;                       /* '<S18>/Add2' */
  real32_T Abs;                        /* '<S18>/Abs' */
  real32_T Switch2;                    /* '<S18>/Switch2' */
  real32_T AccPed01;                   /* '<S2>/Switch' */
  real32_T AccPed02;                   /* '<S2>/Switch2' */
  real32_T Switch4;                    /* '<S2>/Switch4' */
  real32_T Switch1_b;                  /* '<S2>/Switch1' */
  real32_T RTD_st;                     /* '<S2>/Switch5' */
  real32_T Delay;                      /* '<S2>/Delay' */
  real32_T Switch7;                    /* '<S2>/Switch7' */
  real32_T Switch8;                    /* '<S2>/Switch8' */
  real32_T Switch3;                    /* '<S2>/Switch3' */
  real32_T Switch_h;                   /* '<S7>/Switch' */
  real32_T Sum;                        /* '<S7>/Sum' */
  real32_T DataTypeConversion4;        /* '<S2>/Data Type Conversion4' */
  real32_T AccPed1Curve;               /* '<S2>/AccPed1Curve' */
  real32_T Switch9;                    /* '<S2>/Switch9' */
  real32_T DataTypeConversion5;        /* '<S2>/Data Type Conversion5' */
  real32_T Curve1;                     /* '<S2>/Curve1' */
  real32_T DataTypeConversion2;        /* '<S2>/Data Type Conversion2' */
  real32_T Curve2;                     /* '<S2>/Curve2' */
  real32_T DataTypeConversion3;        /* '<S2>/Data Type Conversion3' */
  real32_T AccPed2Curve;               /* '<S2>/AccPed2Curve' */
  real32_T DataTypeConversion1;        /* '<S2>/Data Type Conversion1' */
  real32_T Curve3;                     /* '<S2>/Curve3' */
  uint16_T AnalogInput7;               /* '<S2>/Analog Input7' */
  uint16_T AnalogInput6;               /* '<S2>/Analog Input6' */
  uint16_T AnalogInput5;               /* '<S2>/Analog Input5' */
  uint16_T AnalogInput4;               /* '<S2>/Analog Input4' */
  uint16_T AnalogInput1;               /* '<S2>/Analog Input1' */
  uint8_T Output;                      /* '<S29>/Output' */
  uint8_T Output_p;                    /* '<S30>/Output' */
  uint8_T FixPtSum1;                   /* '<S31>/FixPt Sum1' */
  uint8_T FixPtSwitch;                 /* '<S32>/FixPt Switch' */
  uint8_T FixPtSum1_b;                 /* '<S33>/FixPt Sum1' */
  uint8_T FixPtSwitch_o;               /* '<S34>/FixPt Switch' */
  boolean_T Compare;                   /* '<S9>/Compare' */
  boolean_T Switch_i;                  /* '<S4>/Switch' */
  boolean_T Compare_a;                 /* '<S27>/Compare' */
  boolean_T Compare_h;                 /* '<S20>/Compare' */
  boolean_T Compare_g;                 /* '<S21>/Compare' */
  boolean_T AND;                       /* '<S18>/AND' */
  boolean_T Compare_ge;                /* '<S28>/Compare' */
  boolean_T Compare_c;                 /* '<S22>/Compare' */
  boolean_T Compare_h2;                /* '<S23>/Compare' */
  boolean_T AND1;                      /* '<S18>/AND1' */
  boolean_T Compare_d;                 /* '<S25>/Compare' */
  boolean_T NOT1;                      /* '<S19>/NOT1' */
  boolean_T NOT2;                      /* '<S19>/NOT2' */
  boolean_T AND1_g;                    /* '<S19>/AND1' */
  boolean_T Compare_o;                 /* '<S26>/Compare' */
  boolean_T AND2;                      /* '<S18>/AND2' */
  boolean_T Compare_i;                 /* '<S24>/Compare' */
  boolean_T NOT;                       /* '<S18>/NOT' */
  boolean_T NOT_f;                     /* '<S6>/NOT' */
  boolean_T LogicalOperator;           /* '<S6>/Logical Operator' */
  boolean_T Switch_a;                  /* '<S1>/Switch' */
  boolean_T Delay1;                    /* '<S2>/Delay1' */
  boolean_T Compare_j;                 /* '<S8>/Compare' */
  boolean_T AND_a;                     /* '<S2>/AND' */
  boolean_T DigitalInput4;             /* '<S2>/Digital Input4' */
  boolean_T DigitalInput3;             /* '<S2>/Digital Input3' */
  boolean_T DigitalInput2;             /* '<S2>/Digital Input2' */
  boolean_T DigitalInput1;             /* '<S2>/Digital Input1' */
  boolean_T DigitalInput;              /* '<S2>/Digital Input' */
} B_Torque_Control_ESP32_V6_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  codertarget_arduinobase_inter_T obj; /* '<S2>/Analog Input7' */
  codertarget_arduinobase_inter_T obj_j;/* '<S2>/Analog Input6' */
  codertarget_arduinobase_inter_T obj_a;/* '<S2>/Analog Input5' */
  codertarget_arduinobase_inter_T obj_ac;/* '<S2>/Analog Input4' */
  codertarget_arduinobase_inter_T obj_h;/* '<S2>/Analog Input1' */
  codertarget_arduinobase_blo_l_T obj_p;/* '<S2>/Digital Input4' */
  codertarget_arduinobase_blo_l_T obj_c;/* '<S2>/Digital Input3' */
  codertarget_arduinobase_blo_l_T obj_n;/* '<S2>/Digital Input2' */
  codertarget_arduinobase_blo_l_T obj_g;/* '<S2>/Digital Input1' */
  codertarget_arduinobase_blo_l_T obj_ny;/* '<S2>/Digital Input' */
  codertarget_arduinobase_block_T obj_d;/* '<S3>/Digital Output2' */
  codertarget_arduinobase_block_T obj_o;/* '<S3>/Digital Output1' */
  codertarget_arduinobase_block_T obj_ds;/* '<S3>/Digital Output' */
  real32_T Delay_DSTATE[2];            /* '<S2>/Delay' */
  real32_T Mean_AccVal;                /* '<S18>/Mean' */
  real32_T Mean1_AccVal;               /* '<S18>/Mean1' */
  int32_T clockTickCounter;            /* '<S4>/Pulse Generator1' */
  uint32_T Mean_Iteration;             /* '<S18>/Mean' */
  uint32_T Mean1_Iteration;            /* '<S18>/Mean1' */
  uint8_T Output_DSTATE;               /* '<S29>/Output' */
  uint8_T Output_DSTATE_n;             /* '<S30>/Output' */
  boolean_T Delay1_DSTATE[15];         /* '<S2>/Delay1' */
  boolean_T objisempty;                /* '<S2>/Digital Input4' */
  boolean_T objisempty_m;              /* '<S2>/Digital Input3' */
  boolean_T objisempty_l;              /* '<S2>/Digital Input2' */
  boolean_T objisempty_g;              /* '<S2>/Digital Input1' */
  boolean_T objisempty_a;              /* '<S2>/Digital Input' */
  boolean_T objisempty_e;              /* '<S2>/Analog Input7' */
  boolean_T objisempty_j;              /* '<S2>/Analog Input6' */
  boolean_T objisempty_d;              /* '<S2>/Analog Input5' */
  boolean_T objisempty_n;              /* '<S2>/Analog Input4' */
  boolean_T objisempty_nl;             /* '<S2>/Analog Input1' */
  boolean_T objisempty_c;              /* '<S3>/Digital Output2' */
  boolean_T objisempty_f;              /* '<S3>/Digital Output1' */
  boolean_T objisempty_fg;             /* '<S3>/Digital Output' */
} DW_Torque_Control_ESP32_V6_T;

/* Zero-crossing (trigger) state */
typedef struct {
  ZCSigState TriggeredSubsystem_Trig_ZCE;/* '<S2>/Triggered Subsystem' */
} PrevZCX_Torque_Control_ESP32__T;

/* Parameters (default storage) */
struct P_Torque_Control_ESP32_V6_T_ {
  real32_T CompareToConstant_const;   /* Mask Parameter: CompareToConstant_const
                                       * Referenced by: '<S8>/Constant'
                                       */
  real32_T CompareToConstant_const_b;
                                    /* Mask Parameter: CompareToConstant_const_b
                                     * Referenced by: '<S20>/Constant'
                                     */
  real32_T CompareToConstant1_const; /* Mask Parameter: CompareToConstant1_const
                                      * Referenced by: '<S21>/Constant'
                                      */
  real32_T CompareToConstant2_const; /* Mask Parameter: CompareToConstant2_const
                                      * Referenced by: '<S22>/Constant'
                                      */
  real32_T CompareToConstant3_const; /* Mask Parameter: CompareToConstant3_const
                                      * Referenced by: '<S23>/Constant'
                                      */
  real32_T CompareToConstant5_const; /* Mask Parameter: CompareToConstant5_const
                                      * Referenced by: '<S25>/Constant'
                                      */
  real32_T CompareToConstant4_const; /* Mask Parameter: CompareToConstant4_const
                                      * Referenced by: '<S24>/Constant'
                                      */
  real32_T CompareToConstant_const_a;
                                    /* Mask Parameter: CompareToConstant_const_a
                                     * Referenced by: '<S9>/Constant'
                                     */
  boolean_T CompareToConstant6_const;/* Mask Parameter: CompareToConstant6_const
                                      * Referenced by: '<S26>/Constant'
                                      */
  uint8_T WrapToZero_Threshold;        /* Mask Parameter: WrapToZero_Threshold
                                        * Referenced by: '<S32>/FixPt Switch'
                                        */
  uint8_T WrapToZero_Threshold_b;      /* Mask Parameter: WrapToZero_Threshold_b
                                        * Referenced by: '<S34>/FixPt Switch'
                                        */
  uint8_T CompareToConstant7_const;  /* Mask Parameter: CompareToConstant7_const
                                      * Referenced by: '<S27>/Constant'
                                      */
  uint8_T CompareToConstant8_const;  /* Mask Parameter: CompareToConstant8_const
                                      * Referenced by: '<S28>/Constant'
                                      */
  real_T AnalogInput1_SampleTime;      /* Expression: -1
                                        * Referenced by: '<S2>/Analog Input1'
                                        */
  real_T AnalogInput4_SampleTime;      /* Expression: -1
                                        * Referenced by: '<S2>/Analog Input4'
                                        */
  real_T AnalogInput5_SampleTime;      /* Expression: -1
                                        * Referenced by: '<S2>/Analog Input5'
                                        */
  real_T AnalogInput6_SampleTime;      /* Expression: -1
                                        * Referenced by: '<S2>/Analog Input6'
                                        */
  real_T AnalogInput7_SampleTime;      /* Expression: -1
                                        * Referenced by: '<S2>/Analog Input7'
                                        */
  real_T DigitalInput_SampleTime;      /* Expression: -1
                                        * Referenced by: '<S2>/Digital Input'
                                        */
  real_T DigitalInput1_SampleTime;     /* Expression: -1
                                        * Referenced by: '<S2>/Digital Input1'
                                        */
  real_T DigitalInput2_SampleTime;     /* Expression: -1
                                        * Referenced by: '<S2>/Digital Input2'
                                        */
  real_T DigitalInput3_SampleTime;     /* Expression: -1
                                        * Referenced by: '<S2>/Digital Input3'
                                        */
  real_T DigitalInput4_SampleTime;     /* Expression: -1
                                        * Referenced by: '<S2>/Digital Input4'
                                        */
  real_T Constant13_Value;             /* Expression: 0
                                        * Referenced by: '<S2>/Constant13'
                                        */
  real_T Constant10_Value;             /* Expression: 1
                                        * Referenced by: '<S2>/Constant10'
                                        */
  real_T Constant14_Value;             /* Expression: 60
                                        * Referenced by: '<S2>/Constant14'
                                        */
  real_T Constant16_Value;             /* Expression: 0
                                        * Referenced by: '<S2>/Constant16'
                                        */
  real_T Constant15_Value;             /* Expression: 1
                                        * Referenced by: '<S2>/Constant15'
                                        */
  real_T Constant19_Value;             /* Expression: 0
                                        * Referenced by: '<S2>/Constant19'
                                        */
  real_T Constant9_Value;              /* Expression: 5000
                                        * Referenced by: '<S2>/Constant9'
                                        */
  real_T Constant11_Value;             /* Expression: 0
                                        * Referenced by: '<S2>/Constant11'
                                        */
  real_T Switch9_Threshold;            /* Expression: 0
                                        * Referenced by: '<S2>/Switch9'
                                        */
  real_T VehSpd_Value;                 /* Expression: 24.11483253588517
                                        * Referenced by: '<S2>/VehSpd'
                                        */
  real_T sec1_Value;                   /* Expression: 2*pi*0.3*3.6
                                        * Referenced by: '<S2>/sec1'
                                        */
  real_T sec_Value;                    /* Expression: 60
                                        * Referenced by: '<S2>/sec'
                                        */
  real_T TransmRatio_Value;            /* Expression: 8
                                        * Referenced by: '<S2>/TransmRatio'
                                        */
  real_T Constant1_Value;              /* Expression: 0
                                        * Referenced by: '<S2>/Constant1'
                                        */
  real_T Constant2_Value;              /* Expression: 0
                                        * Referenced by: '<S2>/Constant2'
                                        */
  real_T Switch_Threshold;             /* Expression: 0
                                        * Referenced by: '<S2>/Switch'
                                        */
  real_T Switch2_Threshold;            /* Expression: 0
                                        * Referenced by: '<S2>/Switch2'
                                        */
  real_T Constant4_Value;              /* Expression: 0
                                        * Referenced by: '<S2>/Constant4'
                                        */
  real_T Switch4_Threshold;            /* Expression: 0
                                        * Referenced by: '<S2>/Switch4'
                                        */
  real_T Constant_Value;               /* Expression: 1
                                        * Referenced by: '<S2>/Constant'
                                        */
  real_T Switch1_Threshold;            /* Expression: 0
                                        * Referenced by: '<S2>/Switch1'
                                        */
  real_T Constant5_Value;              /* Expression: 0
                                        * Referenced by: '<S2>/Constant5'
                                        */
  real_T Switch5_Threshold;            /* Expression: 0
                                        * Referenced by: '<S2>/Switch5'
                                        */
  real_T Constant6_Value;              /* Expression: 0
                                        * Referenced by: '<S2>/Constant6'
                                        */
  real_T Switch6_Threshold;            /* Expression: 0
                                        * Referenced by: '<S2>/Switch6'
                                        */
  real_T Constant7_Value;              /* Expression: 0
                                        * Referenced by: '<S2>/Constant7'
                                        */
  real_T Constant8_Value;              /* Expression: 0
                                        * Referenced by: '<S2>/Constant8'
                                        */
  real_T Switch7_Threshold;            /* Expression: 0
                                        * Referenced by: '<S2>/Switch7'
                                        */
  real_T Switch8_Threshold;            /* Expression: 0
                                        * Referenced by: '<S2>/Switch8'
                                        */
  real_T Constant3_Value;              /* Expression: 0
                                        * Referenced by: '<S2>/Constant3'
                                        */
  real_T Switch3_Threshold;            /* Expression: 0
                                        * Referenced by: '<S2>/Switch3'
                                        */
  real_T Constant2_Value_g;            /* Expression: 0
                                        * Referenced by: '<S18>/Constant2'
                                        */
  real_T Constant4_Value_d;            /* Expression: 0
                                        * Referenced by: '<S18>/Constant4'
                                        */
  real_T Constant_Value_f;             /* Expression: 0
                                        * Referenced by: '<S18>/Constant'
                                        */
  real_T PulseGenerator1_Amp;          /* Expression: 50
                                        * Referenced by: '<S4>/Pulse Generator1'
                                        */
  real_T PulseGenerator1_Period;       /* Expression: 50
                                        * Referenced by: '<S4>/Pulse Generator1'
                                        */
  real_T PulseGenerator1_Duty;         /* Expression: 10
                                        * Referenced by: '<S4>/Pulse Generator1'
                                        */
  real_T PulseGenerator1_PhaseDelay;   /* Expression: 0
                                        * Referenced by: '<S4>/Pulse Generator1'
                                        */
  real32_T Curve3_tableData[2];        /* Expression: Table
                                        * Referenced by: '<S2>/Curve3'
                                        */
  real32_T Curve3_bp01Data[2];         /* Expression: BreakpointsForDimension1
                                        * Referenced by: '<S2>/Curve3'
                                        */
  real32_T AccPed2Curve_tableData[2];  /* Expression: Table
                                        * Referenced by: '<S2>/AccPed2Curve'
                                        */
  real32_T AccPed2Curve_bp01Data[2];   /* Expression: BreakpointsForDimension1
                                        * Referenced by: '<S2>/AccPed2Curve'
                                        */
  real32_T Curve2_tableData[2];        /* Expression: Table
                                        * Referenced by: '<S2>/Curve2'
                                        */
  real32_T Curve2_bp01Data[2];         /* Expression: BreakpointsForDimension1
                                        * Referenced by: '<S2>/Curve2'
                                        */
  real32_T Curve1_tableData[2];        /* Expression: Table
                                        * Referenced by: '<S2>/Curve1'
                                        */
  real32_T Curve1_bp01Data[2];         /* Expression: BreakpointsForDimension1
                                        * Referenced by: '<S2>/Curve1'
                                        */
  real32_T AccPed1Curve_tableData[2];  /* Expression: Table
                                        * Referenced by: '<S2>/AccPed1Curve'
                                        */
  real32_T AccPed1Curve_bp01Data[2];   /* Expression: BreakpointsForDimension1
                                        * Referenced by: '<S2>/AccPed1Curve'
                                        */
  real32_T Constant_Value_l;           /* Computed Parameter: Constant_Value_l
                                        * Referenced by: '<S7>/Constant'
                                        */
  real32_T Constant1_Value_h;          /* Computed Parameter: Constant1_Value_h
                                        * Referenced by: '<S7>/Constant1'
                                        */
  real32_T DrvMode_st_Y0;              /* Computed Parameter: DrvMode_st_Y0
                                        * Referenced by: '<S7>/DrvMode_st'
                                        */
  real32_T AccPed01_Y0;                /* Computed Parameter: AccPed01_Y0
                                        * Referenced by: '<S2>/AccPed01'
                                        */
  real32_T AccPed02_Y0;                /* Computed Parameter: AccPed02_Y0
                                        * Referenced by: '<S2>/AccPed02'
                                        */
  real32_T BrkPedDig_st_Y0;            /* Computed Parameter: BrkPedDig_st_Y0
                                        * Referenced by: '<S2>/BrkPedDig_st'
                                        */
  real32_T BrkPedAnlg_Y0;              /* Computed Parameter: BrkPedAnlg_Y0
                                        * Referenced by: '<S2>/BrkPedAnlg'
                                        */
  real32_T RTD_st_Y0;                  /* Computed Parameter: RTD_st_Y0
                                        * Referenced by: '<S2>/RTD_st'
                                        */
  real32_T AxelRpm_Y0;                 /* Computed Parameter: AxelRpm_Y0
                                        * Referenced by: '<S2>/AxelRpm'
                                        */
  real32_T VehSpeed_Y0;                /* Computed Parameter: VehSpeed_Y0
                                        * Referenced by: '<S2>/VehSpeed'
                                        */
  real32_T TempSensr_Y0;               /* Computed Parameter: TempSensr_Y0
                                        * Referenced by: '<S2>/TempSensr'
                                        */
  real32_T Gear_st_Y0;                 /* Computed Parameter: Gear_st_Y0
                                        * Referenced by: '<S2>/Gear_st'
                                        */
  real32_T Constant12_Value;           /* Computed Parameter: Constant12_Value
                                        * Referenced by: '<S2>/Constant12'
                                        */
  real32_T Delay_InitialCondition; /* Computed Parameter: Delay_InitialCondition
                                    * Referenced by: '<S2>/Delay'
                                    */
  real32_T Constant_Value_i;           /* Computed Parameter: Constant_Value_i
                                        * Referenced by: '<S1>/Constant'
                                        */
  real32_T Constant1_Value_i;          /* Computed Parameter: Constant1_Value_i
                                        * Referenced by: '<S1>/Constant1'
                                        */
  real32_T Switch_Threshold_m;         /* Computed Parameter: Switch_Threshold_m
                                        * Referenced by: '<S1>/Switch'
                                        */
  real32_T brkdefault_Value;           /* Computed Parameter: brkdefault_Value
                                        * Referenced by: '<S6>/brkdefault'
                                        */
  real32_T AccPedReq_Y0;               /* Computed Parameter: AccPedReq_Y0
                                        * Referenced by: '<S6>/AccPedReq'
                                        */
  real32_T AnlgBrkPrsnt_Value;         /* Computed Parameter: AnlgBrkPrsnt_Value
                                        * Referenced by: '<S6>/AnlgBrkPrsnt'
                                        */
  real32_T Switch1_Threshold_f;       /* Computed Parameter: Switch1_Threshold_f
                                       * Referenced by: '<S19>/Switch1'
                                       */
  real32_T NormalMode_tableData[110];  /* Expression: Table
                                        * Referenced by: '<S12>/NormalMode'
                                        */
  real32_T NormalMode_bp01Data[11];    /* Expression: BreakpointsForDimension1
                                        * Referenced by: '<S12>/NormalMode'
                                        */
  real32_T NormalMode_bp02Data[10];    /* Expression: BreakpointsForDimension2
                                        * Referenced by: '<S12>/NormalMode'
                                        */
  real32_T SportMode_tableData[110];   /* Expression: Table
                                        * Referenced by: '<S14>/SportMode'
                                        */
  real32_T SportMode_bp01Data[11];     /* Expression: BreakpointsForDimension1
                                        * Referenced by: '<S14>/SportMode'
                                        */
  real32_T SportMode_bp02Data[10];     /* Expression: BreakpointsForDimension2
                                        * Referenced by: '<S14>/SportMode'
                                        */
  real32_T EcoMode_tableData[110];     /* Expression: Table
                                        * Referenced by: '<S11>/EcoMode'
                                        */
  real32_T EcoMode_bp01Data[11];       /* Expression: BreakpointsForDimension1
                                        * Referenced by: '<S11>/EcoMode'
                                        */
  real32_T EcoMode_bp02Data[10];       /* Expression: BreakpointsForDimension2
                                        * Referenced by: '<S11>/EcoMode'
                                        */
  real32_T Constant_Value_d;           /* Computed Parameter: Constant_Value_d
                                        * Referenced by: '<S10>/Constant'
                                        */
  real32_T sec1_Value_o;               /* Computed Parameter: sec1_Value_o
                                        * Referenced by: '<S5>/sec1'
                                        */
  real32_T sec_Value_e;                /* Computed Parameter: sec_Value_e
                                        * Referenced by: '<S5>/sec'
                                        */
  real32_T TransmRat_Value;            /* Computed Parameter: TransmRat_Value
                                        * Referenced by: '<S5>/TransmRat'
                                        */
  real32_T TrqReq_Y0;                  /* Computed Parameter: TrqReq_Y0
                                        * Referenced by: '<S5>/TrqReq'
                                        */
  real32_T VehSpeedPrsnt_Value;       /* Computed Parameter: VehSpeedPrsnt_Value
                                       * Referenced by: '<S5>/VehSpeedPrsnt'
                                       */
  real32_T Switch1_Threshold_e;       /* Computed Parameter: Switch1_Threshold_e
                                       * Referenced by: '<S5>/Switch1'
                                       */
  real32_T Merge_InitialOutput;       /* Computed Parameter: Merge_InitialOutput
                                       * Referenced by: '<S5>/Merge'
                                       */
  real32_T Constant_Value_ij;          /* Computed Parameter: Constant_Value_ij
                                        * Referenced by: '<S4>/Constant'
                                        */
  uint32_T NormalMode_maxIndex[2];    /* Computed Parameter: NormalMode_maxIndex
                                       * Referenced by: '<S12>/NormalMode'
                                       */
  uint32_T SportMode_maxIndex[2];      /* Computed Parameter: SportMode_maxIndex
                                        * Referenced by: '<S14>/SportMode'
                                        */
  uint32_T EcoMode_maxIndex[2];        /* Computed Parameter: EcoMode_maxIndex
                                        * Referenced by: '<S11>/EcoMode'
                                        */
  boolean_T Delay1_InitialCondition;
                                  /* Computed Parameter: Delay1_InitialCondition
                                   * Referenced by: '<S2>/Delay1'
                                   */
  boolean_T FanReq_Y0;                 /* Computed Parameter: FanReq_Y0
                                        * Referenced by: '<S1>/FanReq'
                                        */
  boolean_T Fault_st_Y0;               /* Computed Parameter: Fault_st_Y0
                                        * Referenced by: '<S6>/Fault_st'
                                        */
  boolean_T LED01_Y0;                  /* Computed Parameter: LED01_Y0
                                        * Referenced by: '<S4>/LED01'
                                        */
  uint8_T Constant_Value_c;            /* Computed Parameter: Constant_Value_c
                                        * Referenced by: '<S32>/Constant'
                                        */
  uint8_T Constant_Value_o;            /* Computed Parameter: Constant_Value_o
                                        * Referenced by: '<S34>/Constant'
                                        */
  uint8_T Output_InitialCondition;/* Computed Parameter: Output_InitialCondition
                                   * Referenced by: '<S29>/Output'
                                   */
  uint8_T Output_InitialCondition_o;
                                /* Computed Parameter: Output_InitialCondition_o
                                 * Referenced by: '<S30>/Output'
                                 */
  uint8_T FixPtConstant_Value;        /* Computed Parameter: FixPtConstant_Value
                                       * Referenced by: '<S31>/FixPt Constant'
                                       */
  uint8_T FixPtConstant_Value_g;    /* Computed Parameter: FixPtConstant_Value_g
                                     * Referenced by: '<S33>/FixPt Constant'
                                     */
};

/* Parameters (default storage) */
typedef struct P_Torque_Control_ESP32_V6_T_ P_Torque_Control_ESP32_V6_T;

/* Real-time Model Data Structure */
struct tag_RTM_Torque_Control_ESP32__T {
  const char_T * volatile errorStatus;
};

/* Block parameters (default storage) */
extern P_Torque_Control_ESP32_V6_T Torque_Control_ESP32_V6_P;

/* Block signals (default storage) */
extern B_Torque_Control_ESP32_V6_T Torque_Control_ESP32_V6_B;

/* Block states (default storage) */
extern DW_Torque_Control_ESP32_V6_T Torque_Control_ESP32_V6_DW;

/* Zero-crossing (trigger) state */
extern PrevZCX_Torque_Control_ESP32__T Torque_Control_ESP32_V6_PrevZCX;

/* Model entry point functions */
extern void Torque_Control_ESP32_V6_initialize(void);
extern void Torque_Control_ESP32_V6_step(void);
extern void Torque_Control_ESP32_V6_terminate(void);

/* Real-time Model object */
extern RT_MODEL_Torque_Control_ESP32_T *const Torque_Control_ESP32_V6_M;
extern volatile boolean_T stopRequested;
extern volatile boolean_T runModel;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<S2>/Constant17' : Unused code path elimination
 * Block '<S2>/Display' : Unused code path elimination
 * Block '<S2>/Display1' : Unused code path elimination
 * Block '<S2>/Display10' : Unused code path elimination
 * Block '<S2>/Display11' : Unused code path elimination
 * Block '<S2>/Display2' : Unused code path elimination
 * Block '<S2>/Display3' : Unused code path elimination
 * Block '<S2>/Display4' : Unused code path elimination
 * Block '<S2>/Display5' : Unused code path elimination
 * Block '<S2>/Display6' : Unused code path elimination
 * Block '<S2>/Display7' : Unused code path elimination
 * Block '<S2>/Display8' : Unused code path elimination
 * Block '<S2>/Display9' : Unused code path elimination
 * Block '<S2>/Gear' : Unused code path elimination
 * Block '<S2>/Switch10' : Unused code path elimination
 * Block '<S7>/Display' : Unused code path elimination
 * Block '<S3>/Display' : Unused code path elimination
 * Block '<S4>/Display' : Unused code path elimination
 * Block '<S4>/Display1' : Unused code path elimination
 * Block '<S4>/Scope' : Unused code path elimination
 * Block '<S5>/Divide2' : Unused code path elimination
 * Block '<S5>/Min' : Unused code path elimination
 * Block '<S5>/NOT' : Unused code path elimination
 * Block '<S5>/OR' : Unused code path elimination
 * Block '<S5>/SafeTrq1' : Unused code path elimination
 * Block '<S13>/Constant' : Unused code path elimination
 * Block '<S13>/Constant1' : Unused code path elimination
 * Block '<S13>/Constant2' : Unused code path elimination
 * Block '<S13>/Divide' : Unused code path elimination
 * Block '<S13>/Divide1' : Unused code path elimination
 * Block '<S13>/Divide2' : Unused code path elimination
 * Block '<S13>/Subtract' : Unused code path elimination
 * Block '<S13>/Switch' : Unused code path elimination
 * Block '<S13>/sec' : Unused code path elimination
 * Block '<S13>/sec1' : Unused code path elimination
 * Block '<S5>/Switch4' : Unused code path elimination
 * Block '<S5>/Switch5' : Unused code path elimination
 * Block '<S15>/Constant' : Unused code path elimination
 * Block '<S15>/Constant1' : Unused code path elimination
 * Block '<S15>/Constant2' : Unused code path elimination
 * Block '<S15>/Constant3' : Unused code path elimination
 * Block '<S15>/Delay' : Unused code path elimination
 * Block '<S15>/Divide1' : Unused code path elimination
 * Block '<S15>/Equal' : Unused code path elimination
 * Block '<S15>/Gain2' : Unused code path elimination
 * Block '<S16>/Data Type Duplicate' : Unused code path elimination
 * Block '<S16>/Data Type Propagation' : Unused code path elimination
 * Block '<S16>/LowerRelop1' : Unused code path elimination
 * Block '<S16>/Switch' : Unused code path elimination
 * Block '<S16>/Switch2' : Unused code path elimination
 * Block '<S16>/UpperRelop' : Unused code path elimination
 * Block '<S17>/Data Type Duplicate' : Unused code path elimination
 * Block '<S17>/Data Type Propagation' : Unused code path elimination
 * Block '<S17>/LowerRelop1' : Unused code path elimination
 * Block '<S17>/Switch' : Unused code path elimination
 * Block '<S17>/Switch2' : Unused code path elimination
 * Block '<S17>/UpperRelop' : Unused code path elimination
 * Block '<S15>/Sum' : Unused code path elimination
 * Block '<S15>/Sum1' : Unused code path elimination
 * Block '<S15>/Switch' : Unused code path elimination
 * Block '<S15>/Switch1' : Unused code path elimination
 * Block '<S15>/TrqMaxEmachine1' : Unused code path elimination
 * Block '<S5>/TrsmRatio' : Unused code path elimination
 * Block '<S5>/WhlTrq//eMachTrq' : Unused code path elimination
 * Block '<S29>/Data Type Propagation' : Unused code path elimination
 * Block '<S31>/FixPt Data Type Duplicate' : Unused code path elimination
 * Block '<S32>/FixPt Data Type Duplicate1' : Unused code path elimination
 * Block '<S30>/Data Type Propagation' : Unused code path elimination
 * Block '<S33>/FixPt Data Type Duplicate' : Unused code path elimination
 * Block '<S34>/FixPt Data Type Duplicate1' : Unused code path elimination
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'Torque_Control_ESP32_V6'
 * '<S1>'   : 'Torque_Control_ESP32_V6/Cooling'
 * '<S2>'   : 'Torque_Control_ESP32_V6/DataAcquisition'
 * '<S3>'   : 'Torque_Control_ESP32_V6/DataTransmission'
 * '<S4>'   : 'Torque_Control_ESP32_V6/GearShift'
 * '<S5>'   : 'Torque_Control_ESP32_V6/PowerTrain'
 * '<S6>'   : 'Torque_Control_ESP32_V6/SafetyCheck'
 * '<S7>'   : 'Torque_Control_ESP32_V6/DataAcquisition/Triggered Subsystem'
 * '<S8>'   : 'Torque_Control_ESP32_V6/DataAcquisition/Triggered Subsystem/Compare To Constant'
 * '<S9>'   : 'Torque_Control_ESP32_V6/GearShift/Compare To Constant'
 * '<S10>'  : 'Torque_Control_ESP32_V6/PowerTrain/Defalut'
 * '<S11>'  : 'Torque_Control_ESP32_V6/PowerTrain/EcoMode'
 * '<S12>'  : 'Torque_Control_ESP32_V6/PowerTrain/NormalMode'
 * '<S13>'  : 'Torque_Control_ESP32_V6/PowerTrain/SlipControl'
 * '<S14>'  : 'Torque_Control_ESP32_V6/PowerTrain/SportMode'
 * '<S15>'  : 'Torque_Control_ESP32_V6/PowerTrain/TrqLim'
 * '<S16>'  : 'Torque_Control_ESP32_V6/PowerTrain/TrqLim/Saturation Dynamic1'
 * '<S17>'  : 'Torque_Control_ESP32_V6/PowerTrain/TrqLim/Saturation Dynamic2'
 * '<S18>'  : 'Torque_Control_ESP32_V6/SafetyCheck/APPS Check'
 * '<S19>'  : 'Torque_Control_ESP32_V6/SafetyCheck/Brake Check'
 * '<S20>'  : 'Torque_Control_ESP32_V6/SafetyCheck/APPS Check/Compare To Constant'
 * '<S21>'  : 'Torque_Control_ESP32_V6/SafetyCheck/APPS Check/Compare To Constant1'
 * '<S22>'  : 'Torque_Control_ESP32_V6/SafetyCheck/APPS Check/Compare To Constant2'
 * '<S23>'  : 'Torque_Control_ESP32_V6/SafetyCheck/APPS Check/Compare To Constant3'
 * '<S24>'  : 'Torque_Control_ESP32_V6/SafetyCheck/APPS Check/Compare To Constant4'
 * '<S25>'  : 'Torque_Control_ESP32_V6/SafetyCheck/APPS Check/Compare To Constant5'
 * '<S26>'  : 'Torque_Control_ESP32_V6/SafetyCheck/APPS Check/Compare To Constant6'
 * '<S27>'  : 'Torque_Control_ESP32_V6/SafetyCheck/APPS Check/Compare To Constant7'
 * '<S28>'  : 'Torque_Control_ESP32_V6/SafetyCheck/APPS Check/Compare To Constant8'
 * '<S29>'  : 'Torque_Control_ESP32_V6/SafetyCheck/APPS Check/Counter Limited'
 * '<S30>'  : 'Torque_Control_ESP32_V6/SafetyCheck/APPS Check/Counter Limited1'
 * '<S31>'  : 'Torque_Control_ESP32_V6/SafetyCheck/APPS Check/Counter Limited/Increment Real World'
 * '<S32>'  : 'Torque_Control_ESP32_V6/SafetyCheck/APPS Check/Counter Limited/Wrap To Zero'
 * '<S33>'  : 'Torque_Control_ESP32_V6/SafetyCheck/APPS Check/Counter Limited1/Increment Real World'
 * '<S34>'  : 'Torque_Control_ESP32_V6/SafetyCheck/APPS Check/Counter Limited1/Wrap To Zero'
 */
#endif                                 /* Torque_Control_ESP32_V6_h_ */
